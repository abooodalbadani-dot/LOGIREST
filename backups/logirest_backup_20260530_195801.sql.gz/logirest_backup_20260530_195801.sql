--
-- PostgreSQL database dump
--

\restrict 8sH2lc4VXEDx5fhsloG78Q3UqKnaiaujgwrZNZuXkOgCZBR5ckgKXhdIjPBcwQf

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: logirest
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO logirest;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: logirest
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AdjustmentDirection; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."AdjustmentDirection" AS ENUM (
    'IN',
    'OUT'
);


ALTER TYPE public."AdjustmentDirection" OWNER TO logirest;

--
-- Name: AdjustmentReason; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."AdjustmentReason" AS ENUM (
    'THEFT',
    'DAMAGE',
    'SPOILAGE',
    'CORRECTION',
    'ADMIN_OVERRIDE'
);


ALTER TYPE public."AdjustmentReason" OWNER TO logirest;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."DocumentType" AS ENUM (
    'PURCHASE_REQUEST',
    'PURCHASE_ORDER',
    'GOODS_RECEIVED_NOTE',
    'INVENTORY_ISSUE',
    'TRANSFER',
    'ADJUSTMENT',
    'KITCHEN_REQUEST',
    'STOCKTAKE'
);


ALTER TYPE public."DocumentType" OWNER TO logirest;

--
-- Name: LockStatus; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."LockStatus" AS ENUM (
    'ACTIVE',
    'STALE',
    'RELEASED'
);


ALTER TYPE public."LockStatus" OWNER TO logirest;

--
-- Name: LockType; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."LockType" AS ENUM (
    'STOCKTAKE',
    'MANUAL'
);


ALTER TYPE public."LockType" OWNER TO logirest;

--
-- Name: LotStatus; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."LotStatus" AS ENUM (
    'ACTIVE',
    'HOLD',
    'EXPIRED',
    'QUARANTINE'
);


ALTER TYPE public."LotStatus" OWNER TO logirest;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'GM',
    'INV_MGR',
    'WH_KEEPER',
    'PROC_OFFICER',
    'APPROVER',
    'AUDITOR',
    'VIEWER',
    'KITCHEN_CHIEF',
    'STORE_MGR'
);


ALTER TYPE public."Role" OWNER TO logirest;

--
-- Name: StocktakeStatus; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."StocktakeStatus" AS ENUM (
    'DRAFT',
    'STARTED',
    'COUNTING',
    'REVIEW',
    'APPROVED',
    'POSTED',
    'CLOSED',
    'CANCELLED'
);


ALTER TYPE public."StocktakeStatus" OWNER TO logirest;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO logirest;

--
-- Name: adjustment_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.adjustment_lines (
    id text NOT NULL,
    "adjustmentId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    quantity numeric(18,4) NOT NULL,
    direction public."AdjustmentDirection" NOT NULL,
    reason public."AdjustmentReason" NOT NULL,
    "unitCost" numeric(18,4)
);


ALTER TABLE public.adjustment_lines OWNER TO logirest;

--
-- Name: adjustments; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.adjustments (
    id text NOT NULL,
    "adjustmentNumber" text NOT NULL,
    "warehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.adjustments OWNER TO logirest;

--
-- Name: approval_events; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.approval_events (
    id text NOT NULL,
    "documentId" text NOT NULL,
    "documentType" public."DocumentType" NOT NULL,
    "fromStatus" text NOT NULL,
    "toStatus" text NOT NULL,
    "actionPerformed" text NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments text,
    "stepNumber" integer NOT NULL,
    "userRole" public."Role" NOT NULL
);


ALTER TABLE public.approval_events OWNER TO logirest;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    "targetTable" text NOT NULL,
    "targetId" text NOT NULL,
    "beforeStateJson" text NOT NULL,
    "afterStateJson" text NOT NULL,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO logirest;

--
-- Name: audit_logs_archive; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.audit_logs_archive (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    "targetTable" text NOT NULL,
    "targetId" text NOT NULL,
    "beforeStateJson" text NOT NULL,
    "afterStateJson" text NOT NULL,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.audit_logs_archive OWNER TO logirest;

--
-- Name: barcode_mappings; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.barcode_mappings (
    id text NOT NULL,
    "itemId" text NOT NULL,
    barcode text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.barcode_mappings OWNER TO logirest;

--
-- Name: branches; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.branches (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.branches OWNER TO logirest;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.categories OWNER TO logirest;

--
-- Name: cost_ledger; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.cost_ledger (
    id text NOT NULL,
    "postedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    quantity numeric(18,4) NOT NULL,
    "unitPrice" numeric(18,4) NOT NULL,
    "newWac" numeric(18,4) NOT NULL,
    "documentId" text NOT NULL,
    "documentType" public."DocumentType" NOT NULL,
    "idempotencyKey" text
);


ALTER TABLE public.cost_ledger OWNER TO logirest;

--
-- Name: currencies; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.currencies (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    "isBase" boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.currencies OWNER TO logirest;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.departments (
    id text NOT NULL,
    "branchId" text NOT NULL,
    name text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.departments OWNER TO logirest;

--
-- Name: document_sequences; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.document_sequences (
    id text NOT NULL,
    branch_id text NOT NULL,
    document_type public."DocumentType" NOT NULL,
    year integer NOT NULL,
    current_sequence integer DEFAULT 0 NOT NULL,
    prefix text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.document_sequences OWNER TO logirest;

--
-- Name: fx_rates; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.fx_rates (
    id text NOT NULL,
    "fromCurrencyId" text NOT NULL,
    "toCurrencyId" text NOT NULL,
    rate numeric(18,6) NOT NULL,
    "effectiveFrom" timestamp(3) without time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.fx_rates OWNER TO logirest;

--
-- Name: goods_received_notes; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.goods_received_notes (
    id text NOT NULL,
    "grnNumber" text NOT NULL,
    "poId" text NOT NULL,
    "warehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.goods_received_notes OWNER TO logirest;

--
-- Name: grn_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.grn_lines (
    id text NOT NULL,
    "grnId" text NOT NULL,
    "itemId" text NOT NULL,
    "quantityReceived" numeric(18,4) NOT NULL,
    "unitPrice" numeric(18,4) NOT NULL,
    "lotId" text
);


ALTER TABLE public.grn_lines OWNER TO logirest;

--
-- Name: idempotency_logs; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.idempotency_logs (
    key text NOT NULL,
    "responseBody" text NOT NULL,
    "statusCode" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.idempotency_logs OWNER TO logirest;

--
-- Name: inventory_issue_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.inventory_issue_lines (
    id text NOT NULL,
    "issueId" text NOT NULL,
    "itemId" text NOT NULL,
    quantity numeric(18,4) NOT NULL
);


ALTER TABLE public.inventory_issue_lines OWNER TO logirest;

--
-- Name: inventory_issues; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.inventory_issues (
    id text NOT NULL,
    "issueNumber" text NOT NULL,
    "warehouseId" text NOT NULL,
    "departmentId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.inventory_issues OWNER TO logirest;

--
-- Name: items; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.items (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "uomId" text NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    "isBatched" boolean DEFAULT false NOT NULL,
    "hasExpiry" boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "reorderPoint" numeric(18,4)
);


ALTER TABLE public.items OWNER TO logirest;

--
-- Name: kitchen_request_items; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.kitchen_request_items (
    id text NOT NULL,
    "requestId" text NOT NULL,
    "itemId" text NOT NULL,
    "quantityRequested" numeric(18,4) NOT NULL,
    "quantityFulfilled" numeric(18,4) NOT NULL,
    CONSTRAINT chk_quantity_fulfilled_non_negative CHECK (("quantityFulfilled" >= (0)::numeric))
);


ALTER TABLE public.kitchen_request_items OWNER TO logirest;

--
-- Name: kitchen_requests; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.kitchen_requests (
    id text NOT NULL,
    "requestNumber" text NOT NULL,
    "departmentId" text NOT NULL,
    "warehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    issue_id text
);


ALTER TABLE public.kitchen_requests OWNER TO logirest;

--
-- Name: lot_allocations; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.lot_allocations (
    id text NOT NULL,
    "issueLineId" text,
    "transferLineId" text,
    "lotId" text NOT NULL,
    "quantityAllocated" numeric(18,4) NOT NULL
);


ALTER TABLE public.lot_allocations OWNER TO logirest;

--
-- Name: lots; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.lots (
    id text NOT NULL,
    "itemId" text NOT NULL,
    "lotNumber" text NOT NULL,
    "receivedDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiryDate" timestamp(3) without time zone,
    status public."LotStatus" DEFAULT 'ACTIVE'::public."LotStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lots OWNER TO logirest;

--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.notification_logs (
    id text NOT NULL,
    "targetRole" public."Role" NOT NULL,
    "warehouseId" text,
    message text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "documentType" public."DocumentType",
    "documentId" text
);


ALTER TABLE public.notification_logs OWNER TO logirest;

--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.outbox_events (
    id text NOT NULL,
    "eventType" text NOT NULL,
    payload jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "lastError" text,
    "processedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    CONSTRAINT outbox_events_status_valid CHECK ((status = ANY (ARRAY['PENDING'::text, 'SUCCEEDED'::text, 'FAILED'::text])))
);


ALTER TABLE public.outbox_events OWNER TO logirest;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.password_reset_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    used_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO logirest;

--
-- Name: po_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.po_lines (
    id text NOT NULL,
    "poId" text NOT NULL,
    "itemId" text NOT NULL,
    quantity numeric(18,4) NOT NULL,
    "unitPrice" numeric(18,4) NOT NULL
);


ALTER TABLE public.po_lines OWNER TO logirest;

--
-- Name: pr_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.pr_lines (
    id text NOT NULL,
    "prId" text NOT NULL,
    "itemId" text NOT NULL,
    quantity numeric(18,4) NOT NULL
);


ALTER TABLE public.pr_lines OWNER TO logirest;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.purchase_orders (
    id text NOT NULL,
    "poNumber" text NOT NULL,
    "prId" text,
    "supplierId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "currencyId" text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.purchase_orders OWNER TO logirest;

--
-- Name: purchase_requests; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.purchase_requests (
    id text NOT NULL,
    "requestNumber" text NOT NULL,
    "branchId" text NOT NULL,
    "warehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "createdById" text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.purchase_requests OWNER TO logirest;

--
-- Name: reconciliation_runs; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.reconciliation_runs (
    id text NOT NULL,
    "ranAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "itemsChecked" integer NOT NULL,
    "discrepanciesFound" integer NOT NULL,
    "frozenItems" text[],
    "durationMs" integer NOT NULL,
    lot_discrepancies_found integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.reconciliation_runs OWNER TO logirest;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    "tokenHash" text NOT NULL,
    "userId" text NOT NULL,
    "sessionId" text NOT NULL,
    "parentTokenId" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "isRevoked" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO logirest;

--
-- Name: stock_ledger; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stock_ledger (
    id text NOT NULL,
    "postedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    quantity numeric(18,4) NOT NULL,
    "documentId" text NOT NULL,
    "documentType" public."DocumentType" NOT NULL,
    "idempotencyKey" text
);


ALTER TABLE public.stock_ledger OWNER TO logirest;

--
-- Name: stock_ledger_archive; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stock_ledger_archive (
    id text NOT NULL,
    "postedAt" timestamp(3) without time zone NOT NULL,
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    quantity numeric(18,4) NOT NULL,
    "documentId" text NOT NULL,
    "documentType" public."DocumentType" NOT NULL,
    "idempotencyKey" text
);


ALTER TABLE public.stock_ledger_archive OWNER TO logirest;

--
-- Name: stocktake_counts; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stocktake_counts (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    "qtyCounted" numeric(18,4) NOT NULL,
    "countedById" text NOT NULL,
    "countedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stocktake_counts OWNER TO logirest;

--
-- Name: stocktake_sessions; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stocktake_sessions (
    id text NOT NULL,
    "sessionNumber" text NOT NULL,
    "warehouseId" text NOT NULL,
    status public."StocktakeStatus" DEFAULT 'DRAFT'::public."StocktakeStatus" NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stocktake_sessions OWNER TO logirest;

--
-- Name: stocktake_snapshots; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stocktake_snapshots (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    "qtySnapshot" numeric(18,4) NOT NULL,
    "wacSnapshot" numeric(18,4) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stocktake_snapshots OWNER TO logirest;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    "contactEmail" text,
    version integer DEFAULT 1 NOT NULL,
    "contactName" text,
    "contactPhone" text,
    "isActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.suppliers OWNER TO logirest;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.system_settings (
    key text NOT NULL,
    value text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.system_settings OWNER TO logirest;

--
-- Name: transfer_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.transfer_lines (
    id text NOT NULL,
    "transferId" text NOT NULL,
    "itemId" text NOT NULL,
    "quantityShipped" numeric(18,4) NOT NULL,
    "quantityReceived" numeric(18,4),
    "varianceReason" text
);


ALTER TABLE public.transfer_lines OWNER TO logirest;

--
-- Name: transfers; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.transfers (
    id text NOT NULL,
    "transferNumber" text NOT NULL,
    "fromWarehouseId" text NOT NULL,
    "toWarehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transfers OWNER TO logirest;

--
-- Name: units_of_measure; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.units_of_measure (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.units_of_measure OWNER TO logirest;

--
-- Name: user_warehouse_scopes; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.user_warehouse_scopes (
    id text NOT NULL,
    "userId" text NOT NULL,
    "warehouseId" text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.user_warehouse_scopes OWNER TO logirest;

--
-- Name: users; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    name text NOT NULL,
    role public."Role" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp(3) without time zone
);


ALTER TABLE public.users OWNER TO logirest;

--
-- Name: warehouse_item_lots; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.warehouse_item_lots (
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text NOT NULL,
    "qtyOnHand" numeric(18,4) DEFAULT 0 NOT NULL,
    "qtyAllocated" numeric(18,4) DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    CONSTRAINT chk_lot_qty_on_hand_non_negative CHECK (("qtyOnHand" >= (0)::numeric)),
    CONSTRAINT chk_qty_non_negative CHECK (("qtyOnHand" >= (0)::numeric)),
    CONSTRAINT warehouse_item_lots_qty_on_hand_nonneg CHECK (("qtyOnHand" >= (0)::numeric))
);


ALTER TABLE public.warehouse_item_lots OWNER TO logirest;

--
-- Name: warehouse_items; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.warehouse_items (
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    "qtyOnHand" numeric(18,4) DEFAULT 0 NOT NULL,
    "qtyAllocated" numeric(18,4) DEFAULT 0 NOT NULL,
    wac numeric(18,4) DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    is_frozen boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_qty_on_hand_non_negative CHECK (("qtyOnHand" >= (0)::numeric)),
    CONSTRAINT warehouse_items_qty_allocated_nonneg CHECK (("qtyAllocated" >= (0)::numeric)),
    CONSTRAINT warehouse_items_qty_on_hand_nonneg CHECK (("qtyOnHand" >= (0)::numeric))
);


ALTER TABLE public.warehouse_items OWNER TO logirest;

--
-- Name: warehouse_locks; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.warehouse_locks (
    id text NOT NULL,
    "warehouseId" text NOT NULL,
    "lockType" public."LockType" NOT NULL,
    "lockedById" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    status public."LockStatus" DEFAULT 'ACTIVE'::public."LockStatus" NOT NULL
);


ALTER TABLE public.warehouse_locks OWNER TO logirest;

--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.warehouses (
    id text NOT NULL,
    "branchId" text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    "isLocked" boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.warehouses OWNER TO logirest;

--
-- Name: yield_batches; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.yield_batches (
    id text NOT NULL,
    recipe_name text NOT NULL,
    category text NOT NULL,
    warehouse_id text,
    input_qty double precision NOT NULL,
    output_qty double precision NOT NULL,
    waste_qty double precision NOT NULL,
    yield_pct double precision NOT NULL,
    standard_yield double precision NOT NULL,
    efficiency double precision NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.yield_batches OWNER TO logirest;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
e1e8acce-4d8f-42a6-801e-a7d8896267d0	a27a4f61f79b950e03cc285c3077a713b81ed1d2260a81f9199f27169bd69fc1	2026-05-29 19:41:35.984096+00	0001_init	\N	\N	2026-05-29 19:41:35.294445+00	1
a2cdfe8b-412e-40d9-bad0-2900a9d98133	5bcff1398948809884901b5337e62f1d44cd76badc342959ab06e95f45763f13	2026-05-29 19:41:36.037391+00	20260523204900_drift_delta_hardening	\N	\N	2026-05-29 19:41:35.987096+00	1
106d6008-9b2f-4320-87e5-688ee8b45d51	c79c6a099e050ddb2064648f71fb81c61539704b1eab7f170b998bf1e822fb1e	\N	20260530172800_add_qty_on_hand_check	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260530172800_add_qty_on_hand_check\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "InventoryLot" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"InventoryLot\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(434), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260530172800_add_qty_on_hand_check"\n             at schema-engine\\connectors\\sql-schema-connector\\src\\apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260530172800_add_qty_on_hand_check"\n             at schema-engine\\commands\\src\\commands\\apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine\\core\\src\\state.rs:260	2026-05-30 17:32:26.83129+00	2026-05-30 17:30:16.89538+00	0
b401cad5-13a9-4bc8-b62e-be1bea368b26	5d07efc92ba1812887899f83edc274cf01a9a2e3b8510db6c56092338aff62ad	2026-05-29 19:41:36.080464+00	20260524000000_add_document_sequence_and_is_frozen	\N	\N	2026-05-29 19:41:36.041024+00	1
d1827bab-d808-4eee-8c3c-1b6f25dd0867	62dc08c9b0950e1076f0377f4b876d5d255cdd13ac0236860c761565c799d869	2026-05-29 19:41:36.143627+00	20260524020000_sprint1_add_indexes	\N	\N	2026-05-29 19:41:36.086813+00	1
a3220b57-9f86-4961-b360-d810dfda05fa	380c240522ddb59bd6e768f9984bb278aac14245caf0ca5f962d850238f569e7	2026-05-29 19:41:36.160838+00	20260525000000_extend_supplier_model	\N	\N	2026-05-29 19:41:36.146986+00	1
6f1b0009-ea6b-4c27-9f02-af2cebfe6146	1582ab3029328c12c8e760c6675a031caf5c9920a0daf0741627e7ccce68ab5a	2026-05-30 17:32:41.65631+00	20260530172800_add_qty_on_hand_check	\N	\N	2026-05-30 17:32:41.62474+00	1
10602865-8c41-4b4d-8178-5ab9fa13512e	d5e75a151393b1e50d761b570524dd6bc8ce378fcae3a68b42caf71ddaa93564	2026-05-29 19:41:36.23173+00	20260525024637_add_reorder_point	\N	\N	2026-05-29 19:41:36.164307+00	1
573520e3-f110-4cb1-9250-f015fcb8ff3d	a96059be9881de4745cdc0070e978dc014c3c8ce1aa7a9c240366c3f324750e5	2026-05-29 19:41:36.249851+00	20260525172054_add_nonneg_qty_constraints	\N	\N	2026-05-29 19:41:36.237814+00	1
0caae79e-8ef2-4692-8291-ec83219adb50	b9e93edcc7cb652d23e60d5474c666002bbcd8163795d8ba1fa43894d7f03637	2026-05-29 19:41:36.293408+00	20260525222604_add_system_settings_and_optional_audit_log	\N	\N	2026-05-29 19:41:36.253299+00	1
571f6887-a6ff-4171-9c98-75a217d12cc1	9e477efb1f78a632f9ea1e11a25efc2466be4bbbb2325bb82b01f190b36e88af	2026-05-29 19:41:36.328236+00	20260526015529_add_archival_tables	\N	\N	2026-05-29 19:41:36.296383+00	1
802a33c9-3908-4bfa-b6b2-3c2c0edf1130	39e4fc89c6150b7f938a9d688728e9f6f3f973118abaeb9a1c213b868610f5e1	2026-05-29 19:41:36.343028+00	20260526163716_add_nonneg_qty_constraints	\N	\N	2026-05-29 19:41:36.331181+00	1
d29cbb33-987b-4597-a8de-5330553103e7	44f6ca919d33a8b4b833e4e74a5bfe294751fccfad091fdcbcf27e7e9ea8d90a	2026-05-29 19:41:36.360133+00	20260527000000_add_production_indexes	\N	\N	2026-05-29 19:41:36.345783+00	1
d8b5532c-8f2d-4a3d-8392-ca0af8f9b3c4	f2184d213b99cbd7120940097c4a14aa71f116666a9393aa7a2e17bb1cd77604	2026-05-29 19:41:36.378633+00	20260528210535_add_workflow_query_indexes	\N	\N	2026-05-29 19:41:36.362653+00	1
f8d37643-e232-4ab3-8ccb-292d848a67a6	a3a763363096e5fd6396606488691126485ffca96b77476906fbced876e69ead	2026-05-30 00:53:46.983358+00	20260530034500_risk_remediation_changes	\N	\N	2026-05-30 00:53:46.874488+00	1
\.


--
-- Data for Name: adjustment_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.adjustment_lines (id, "adjustmentId", "itemId", "lotId", quantity, direction, reason, "unitCost") FROM stdin;
\.


--
-- Data for Name: adjustments; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.adjustments (id, "adjustmentNumber", "warehouseId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: approval_events; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.approval_events (id, "documentId", "documentType", "fromStatus", "toStatus", "actionPerformed", "userId", "createdAt", comments, "stepNumber", "userRole") FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.audit_logs (id, "userId", action, "targetTable", "targetId", "beforeStateJson", "afterStateJson", "ipAddress", "createdAt") FROM stdin;
5d7448ba-f579-4733-99a7-c35025149665	c8142c2a-7916-48d0-8d01-5af8c86b80b6	LOGIN_FAILED	users	c8142c2a-7916-48d0-8d01-5af8c86b80b6	{"email":"admin@logirest.com","reason":"invalid_password"}	{"attempt":"FAILED"}	::1	2026-05-29 19:50:10.505
5d597a87-1891-4ab0-b00b-80454e247df5	c8142c2a-7916-48d0-8d01-5af8c86b80b6	LOGIN_SUCCESS	users	c8142c2a-7916-48d0-8d01-5af8c86b80b6	{}	{"email":"admin@logirest.com","role":"ADMIN"}	::ffff:127.0.0.1	2026-05-30 15:13:39.916
689c7e07-337e-43d6-830b-8f34569e6ea0	c8142c2a-7916-48d0-8d01-5af8c86b80b6	LOGIN_SUCCESS	users	c8142c2a-7916-48d0-8d01-5af8c86b80b6	{}	{"email":"admin@logirest.com","role":"ADMIN"}	::ffff:127.0.0.1	2026-05-30 15:17:42.732
1509d89a-9ee2-4c66-aaf8-bf1bfe860d35	c8142c2a-7916-48d0-8d01-5af8c86b80b6	LOGIN_SUCCESS	users	c8142c2a-7916-48d0-8d01-5af8c86b80b6	{}	{"email":"admin@logirest.com","role":"ADMIN"}	::ffff:127.0.0.1	2026-05-30 16:13:33.734
c35b5d6f-3b7a-4287-8af0-d3a830c559f3	c8142c2a-7916-48d0-8d01-5af8c86b80b6	LOGIN_FAILED	users	c8142c2a-7916-48d0-8d01-5af8c86b80b6	{"email":"admin@logirest.com","reason":"invalid_password"}	{"attempt":"FAILED"}	::1	2026-05-30 18:53:22.056
b15eb097-aab0-42a9-ab55-922f8cdd6a6f	650501a7-3e78-4d4e-bf8e-f8100e157f2c	LOGIN_SUCCESS	users	650501a7-3e78-4d4e-bf8e-f8100e157f2c	{}	{"email":"admin@logirest.local","role":"ADMIN"}	::1	2026-05-30 18:55:50.62
83c574ed-b36c-4c90-b032-06c9ec6ec8c0	650501a7-3e78-4d4e-bf8e-f8100e157f2c	LOGIN_SUCCESS	users	650501a7-3e78-4d4e-bf8e-f8100e157f2c	{}	{"email":"admin@logirest.local","role":"ADMIN"}	::1	2026-05-30 19:08:23.015
45f11209-6c88-46de-9177-658fb6e00a13	650501a7-3e78-4d4e-bf8e-f8100e157f2c	LOGIN_SUCCESS	users	650501a7-3e78-4d4e-bf8e-f8100e157f2c	{}	{"email":"admin@logirest.local","role":"ADMIN"}	::1	2026-05-30 19:10:22.852
17a27f1b-3c8d-41b7-9052-c6abb5e7ba16	650501a7-3e78-4d4e-bf8e-f8100e157f2c	LOGIN_SUCCESS	users	650501a7-3e78-4d4e-bf8e-f8100e157f2c	{}	{"email":"admin@logirest.local","role":"ADMIN"}	::1	2026-05-30 19:14:23.657
\.


--
-- Data for Name: audit_logs_archive; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.audit_logs_archive (id, "userId", action, "targetTable", "targetId", "beforeStateJson", "afterStateJson", "ipAddress", "createdAt") FROM stdin;
\.


--
-- Data for Name: barcode_mappings; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.barcode_mappings (id, "itemId", barcode, version) FROM stdin;
f3cba036-d4ed-4aed-b93e-09c459b42ef9	f9ea30dc-1fc2-4f71-9db2-0e9e20a0796b	8801234567890	1
efbd1b74-73a2-4812-b577-e99ade844675	bc356d01-59ac-4ae5-80c2-9db786919818	8801234567891	1
fb39fe9b-cb12-4296-b75a-ffe27e00527d	054bf295-ad6f-401c-bc24-b4a58a256840	8801234567892	1
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.branches (id, name, code, version, "createdAt") FROM stdin;
11987f31-633f-4451-bdf0-07297429be78	Main Branch - HQ	HQ	1	2026-05-29 19:41:44.113
10c0293f-c6f7-400a-bc1c-f094dc48ad4c	North Branch	NORTH	1	2026-05-29 19:41:44.186
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.categories (id, name, version) FROM stdin;
0f18fa05-c75d-4a11-811b-81c83ba17f3a	Default Category	1
3f3a940a-3551-4e74-9dce-2af5d40adf6d	Meat & Poultry	1
084c4c94-6c53-47a4-9fcd-eafbbe534d42	Dry Goods	1
6c904d12-c2b8-48de-a68a-b1426b535670	Fresh Produce	1
8a4b4f32-0fed-4187-be59-6e0c25ccc0fa	Seafood	1
ccc15e0d-d103-4e2c-8891-aa560eb37e20	Dairy	1
7a940351-7a0c-407b-84b1-618d9f4df7b6	Frozen	1
5e73400d-a3d7-4e7d-8b9d-37d5d0d1234f	Beverages	1
be9b7c96-e537-42d4-9071-62506a856f40	Cleaning Supplies	1
6772e9e6-a89a-4153-b706-82bebecdd3bd	Disposable	1
18552350-140b-4432-8cef-2470d17dc1e3	Spices & Seasoning	1
\.


--
-- Data for Name: cost_ledger; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.cost_ledger (id, "postedAt", "warehouseId", "itemId", quantity, "unitPrice", "newWac", "documentId", "documentType", "idempotencyKey") FROM stdin;
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.currencies (id, code, name, "isBase", version) FROM stdin;
377d90f5-ad5c-41fa-a6c1-8d8a8ffdaca9	SAR	Saudi Riyal	t	1
03534cf6-b53e-475b-843f-32c4379a6f46	USD	US Dollar	f	1
412e9f1e-f646-40ec-a93c-575fe919f69c	EUR	Euro	f	1
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.departments (id, "branchId", name, version) FROM stdin;
9dd58788-3e19-4963-a908-d156e8561443	11987f31-633f-4451-bdf0-07297429be78	Hot Kitchen	1
65691b06-6f0d-496a-9d9a-c8f2d9d7d772	11987f31-633f-4451-bdf0-07297429be78	Cold Kitchen	1
d0421297-410a-4574-bffa-4144b9e0ad55	11987f31-633f-4451-bdf0-07297429be78	Bakery	1
93ba1151-be1b-40d3-8e13-a9d74c3c9419	11987f31-633f-4451-bdf0-07297429be78	Pastry	1
fa9e60ee-2116-4dc2-a604-5e4e9a590d53	11987f31-633f-4451-bdf0-07297429be78	Stewarding	1
0d2395a4-e3a8-4553-b305-dedca5bcb30d	11987f31-633f-4451-bdf0-07297429be78	Main Kitchen	1
\.


--
-- Data for Name: document_sequences; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.document_sequences (id, branch_id, document_type, year, current_sequence, prefix, created_at, updated_at) FROM stdin;
8882f063-fdef-4105-a4e1-f837a309c7e3	11987f31-633f-4451-bdf0-07297429be78	KITCHEN_REQUEST	2026	0	KR-2026-HQ	2026-05-30 15:37:54.471	2026-05-30 15:37:54.471
36705e27-679e-4ef2-b0c8-ce5d25ae8281	10c0293f-c6f7-400a-bc1c-f094dc48ad4c	KITCHEN_REQUEST	2026	0	KR-2026-NORTH	2026-05-30 15:37:54.489	2026-05-30 15:37:54.489
\.


--
-- Data for Name: fx_rates; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.fx_rates (id, "fromCurrencyId", "toCurrencyId", rate, "effectiveFrom", version) FROM stdin;
fx-sar-usd-1	377d90f5-ad5c-41fa-a6c1-8d8a8ffdaca9	03534cf6-b53e-475b-843f-32c4379a6f46	0.266667	2026-05-29 19:41:43.125	1
fx-usd-sar-1	03534cf6-b53e-475b-843f-32c4379a6f46	377d90f5-ad5c-41fa-a6c1-8d8a8ffdaca9	3.750000	2026-05-29 19:41:43.354	1
\.


--
-- Data for Name: goods_received_notes; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.goods_received_notes (id, "grnNumber", "poId", "warehouseId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: grn_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.grn_lines (id, "grnId", "itemId", "quantityReceived", "unitPrice", "lotId") FROM stdin;
\.


--
-- Data for Name: idempotency_logs; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.idempotency_logs (key, "responseBody", "statusCode", "createdAt") FROM stdin;
\.


--
-- Data for Name: inventory_issue_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.inventory_issue_lines (id, "issueId", "itemId", quantity) FROM stdin;
\.


--
-- Data for Name: inventory_issues; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.inventory_issues (id, "issueNumber", "warehouseId", "departmentId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.items (id, "categoryId", "uomId", name, sku, "isBatched", "hasExpiry", version, "createdAt", "isActive", "reorderPoint") FROM stdin;
f9ea30dc-1fc2-4f71-9db2-0e9e20a0796b	084c4c94-6c53-47a4-9fcd-eafbbe534d42	5b6948e9-220a-4c2a-9264-7486f6d52a00	Premium Basmati Rice	RICE-001	f	f	1	2026-05-29 19:41:46.046	t	\N
bc356d01-59ac-4ae5-80c2-9db786919818	084c4c94-6c53-47a4-9fcd-eafbbe534d42	a1569c95-06ea-4d69-81df-83b382491849	Vegetable Cooking Oil	OIL-002	t	f	1	2026-05-29 19:41:46.061	t	\N
054bf295-ad6f-401c-bc24-b4a58a256840	ccc15e0d-d103-4e2c-8891-aa560eb37e20	a1569c95-06ea-4d69-81df-83b382491849	Fresh Whole Milk	MILK-003	t	t	1	2026-05-29 19:41:46.069	t	\N
\.


--
-- Data for Name: kitchen_request_items; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.kitchen_request_items (id, "requestId", "itemId", "quantityRequested", "quantityFulfilled") FROM stdin;
\.


--
-- Data for Name: kitchen_requests; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.kitchen_requests (id, "requestNumber", "departmentId", "warehouseId", status, version, "createdAt", issue_id) FROM stdin;
\.


--
-- Data for Name: lot_allocations; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.lot_allocations (id, "issueLineId", "transferLineId", "lotId", "quantityAllocated") FROM stdin;
\.


--
-- Data for Name: lots; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.lots (id, "itemId", "lotNumber", "receivedDate", "expiryDate", status, "createdAt") FROM stdin;
236207c7-77a3-427d-9310-d99ee2457460	bc356d01-59ac-4ae5-80c2-9db786919818	LOT-OIL-001	2026-05-29 19:41:46.109	\N	ACTIVE	2026-05-29 19:41:46.11
a84ff155-adf9-46a0-8608-145fbd602ce8	054bf295-ad6f-401c-bc24-b4a58a256840	LOT-MILK-001	2026-05-29 19:41:46.123	2026-06-28 19:41:46.123	ACTIVE	2026-05-29 19:41:46.124
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.notification_logs (id, "targetRole", "warehouseId", message, "isRead", "createdAt", "documentType", "documentId") FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.outbox_events (id, "eventType", payload, status, attempts, "lastError", "processedAt", "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: po_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.po_lines (id, "poId", "itemId", quantity, "unitPrice") FROM stdin;
\.


--
-- Data for Name: pr_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.pr_lines (id, "prId", "itemId", quantity) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.purchase_orders (id, "poNumber", "prId", "supplierId", status, "currencyId", version, "createdAt") FROM stdin;
\.


--
-- Data for Name: purchase_requests; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.purchase_requests (id, "requestNumber", "branchId", "warehouseId", status, "createdById", version, "createdAt") FROM stdin;
\.


--
-- Data for Name: reconciliation_runs; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.reconciliation_runs (id, "ranAt", "itemsChecked", "discrepanciesFound", "frozenItems", "durationMs", lot_discrepancies_found) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.refresh_tokens (id, "tokenHash", "userId", "sessionId", "parentTokenId", "expiresAt", "isRevoked", "createdAt", version) FROM stdin;
f25344c3-d671-46f9-9562-285f63648a77	f2d1e27095744afcfae8b4b0f4114524c60513cb71901ebf164f2f03c680ba86	650501a7-3e78-4d4e-bf8e-f8100e157f2c	9ebb8b01-cf4b-49a7-b952-36c7fa96c869	\N	2026-06-05 19:44:14.024	f	2026-05-29 19:44:14.025	1
fb59ca68-f45b-4bdf-b62f-da9b72d1d167	706c5107544af6e16c325c51b52e93291b2dcf5c7cbd070a54d260ac9f6d7ff0	650501a7-3e78-4d4e-bf8e-f8100e157f2c	d2b00f70-3a39-43d8-8f55-6a1c03256704	\N	2026-06-05 19:53:52.276	f	2026-05-29 19:53:52.278	1
c60810e8-e63e-4e1f-a0ad-3e2d38830b9b	583f15cbf63f031fc327fcc6ab716461d2a6e9226ffa01358e1107ada47a758a	c8142c2a-7916-48d0-8d01-5af8c86b80b6	0fecfd24-dec4-487f-bee6-492c9bfd4163	\N	2026-06-05 19:59:59.814	f	2026-05-29 19:59:59.815	1
6562e821-bffb-4c61-b1ce-516996e68bf8	b3783b7f12daa16bad2e5d40cc7930d52514e012eb58fd7e926470e07baba591	c8142c2a-7916-48d0-8d01-5af8c86b80b6	a8d9a525-170b-4c85-8cbd-c2b6c2a3bb2d	\N	2026-06-05 20:07:23.108	f	2026-05-29 20:07:23.11	1
5bd3442b-9010-4b2f-8453-76b3fde7de6e	99a2bf4825537b892e503ac99ef11bcd92edd7e47fb6cc24a81a6b7e4296ae04	650501a7-3e78-4d4e-bf8e-f8100e157f2c	5958c3d2-d522-4f98-856b-41a24874a443	\N	2026-06-05 20:14:22.272	t	2026-05-29 20:14:22.274	2
ba57db57-bc71-4493-966f-bd139285e411	1d5465e520542ffc141a8db769576f700b7555be670a1375d4378c13c0425e37	650501a7-3e78-4d4e-bf8e-f8100e157f2c	5958c3d2-d522-4f98-856b-41a24874a443	5bd3442b-9010-4b2f-8453-76b3fde7de6e	2026-06-05 20:24:23.396	f	2026-05-29 20:24:23.397	1
3517dfae-ff97-450d-aa78-1632d774dbd0	cc782ed50e64452209b7f0e46e638bc9558d6d171be90688932c9a5bec282ad8	650501a7-3e78-4d4e-bf8e-f8100e157f2c	2da91df0-f623-4001-9ea5-cb3a80bc4899	\N	2026-06-05 20:54:10.697	t	2026-05-29 20:54:10.699	2
1fb1d10e-ec7a-4b20-b2be-ad8129675518	febc36dd77f0e9a1764e6a7541998c742617f33e479855b001209a577c0800ce	650501a7-3e78-4d4e-bf8e-f8100e157f2c	2da91df0-f623-4001-9ea5-cb3a80bc4899	3517dfae-ff97-450d-aa78-1632d774dbd0	2026-06-05 21:04:11.342	t	2026-05-29 21:04:11.343	2
765bc0c0-ab04-4320-afee-762b21d4dec5	92b14776a2ead2b5872dfa479db42605e11c0c790762ff43e87397808fb5fdfc	650501a7-3e78-4d4e-bf8e-f8100e157f2c	2da91df0-f623-4001-9ea5-cb3a80bc4899	1fb1d10e-ec7a-4b20-b2be-ad8129675518	2026-06-05 21:14:12.386	f	2026-05-29 21:14:12.387	1
189631a7-d5da-4a78-bfa9-75e24ee997cc	0616fa1c1b3c0c09d4d58813a8dce94a20f7bf99d4b04298da50df194210516e	c8142c2a-7916-48d0-8d01-5af8c86b80b6	97e8cc1f-f7a8-4a36-b8c9-44fef7189033	\N	2026-06-05 23:23:25.413	f	2026-05-29 23:23:25.414	1
3b04d6da-66de-4709-ba5f-8221f5bac53d	f725ab41a7a2b75b4302841b06ccb95f1a0645fa8154a48790543dddd9ce8968	c8142c2a-7916-48d0-8d01-5af8c86b80b6	2735be7d-f885-4b49-b0af-8c63c4dd8ce3	\N	2026-06-05 23:27:20.9	f	2026-05-29 23:27:20.913	1
d94f8235-9a50-44e8-b081-07f5f3d9def3	54109e5456106e4627caba70e51b5e3e8e611317f0d133d72ca1ecb9bcf91f59	c8142c2a-7916-48d0-8d01-5af8c86b80b6	94bbc1b7-5e16-48c1-9aa9-ece9ee62beff	\N	2026-06-06 15:13:39.938	f	2026-05-30 15:13:39.94	1
eafebf53-f6b9-42b1-9af9-b29c4345b696	6337f243e71c241d7c9688d4d1a0364090b914a5f04e5b836e41fe4c2c58be90	c8142c2a-7916-48d0-8d01-5af8c86b80b6	2c28f0b3-9ddc-411e-8ad8-cb6962cb35d4	\N	2026-06-06 15:17:42.744	f	2026-05-30 15:17:42.745	1
29c42b32-55e8-4b18-9de3-88b225811fee	74dc1f8041552b150082ff307a296e76ec0e1997e0b6672b5d17101e78556727	c8142c2a-7916-48d0-8d01-5af8c86b80b6	77568eee-551a-4235-988d-b0a150a9496f	\N	2026-06-06 16:13:33.747	f	2026-05-30 16:13:33.748	1
33b582ff-4506-4a86-b84b-e940c8697f7c	2741f0a75a78f1db2dc6f5c54f3976e9ac07451bf296024d9f799e1a33550582	650501a7-3e78-4d4e-bf8e-f8100e157f2c	06cb7044-ebb3-468d-a83f-76fb718ef3b4	\N	2026-06-06 18:55:50.639	f	2026-05-30 18:55:50.641	1
9d18baab-fd9b-4fe8-9e1f-f12df2ab62d2	0e57b9d8415e41a960a6016a5820f26260cfc6128bc2ffd2ab13c8c12647f205	650501a7-3e78-4d4e-bf8e-f8100e157f2c	5abb61f1-6dfe-4cfe-89d9-cc78d0d36c95	\N	2026-06-06 19:08:23.03	f	2026-05-30 19:08:23.033	1
3edf0be9-c3fd-48d2-8034-feca3e5bdcd6	5c8c4f77337e570a1826f02889058e2585317e191b4634de9482e3aee42391eb	650501a7-3e78-4d4e-bf8e-f8100e157f2c	d48e47a8-4590-42f2-80e5-4e8e04db114a	\N	2026-06-06 19:10:22.863	f	2026-05-30 19:10:22.864	1
89a16a0c-3ffb-41c4-8aba-af9757b096b9	dfe1fdc8904eded1274a5bbbc3603b27e6639520dad10e02869e602cafbd29e0	650501a7-3e78-4d4e-bf8e-f8100e157f2c	ba0aee07-ec63-434d-8f53-670f10ebc97f	\N	2026-06-06 19:14:23.677	f	2026-05-30 19:14:23.679	1
\.


--
-- Data for Name: stock_ledger; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stock_ledger (id, "postedAt", "warehouseId", "itemId", "lotId", quantity, "documentId", "documentType", "idempotencyKey") FROM stdin;
ed6fc16e-111e-4f72-bad0-31bbe1d5fd98	2026-05-29 19:41:46.138	d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	f9ea30dc-1fc2-4f71-9db2-0e9e20a0796b	\N	1000.0000	INITIAL_BALANCE	ADJUSTMENT	init-stock-rice
909fe3b6-1ef5-47eb-97bc-382230db2259	2026-05-29 19:41:46.162	d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	bc356d01-59ac-4ae5-80c2-9db786919818	236207c7-77a3-427d-9310-d99ee2457460	500.0000	INITIAL_BALANCE	ADJUSTMENT	init-stock-oil
14d8f1f4-c326-47c7-b329-55037fa765e6	2026-05-29 19:41:46.178	d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	054bf295-ad6f-401c-bc24-b4a58a256840	a84ff155-adf9-46a0-8608-145fbd602ce8	200.0000	INITIAL_BALANCE	ADJUSTMENT	init-stock-milk
\.


--
-- Data for Name: stock_ledger_archive; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stock_ledger_archive (id, "postedAt", "warehouseId", "itemId", "lotId", quantity, "documentId", "documentType", "idempotencyKey") FROM stdin;
\.


--
-- Data for Name: stocktake_counts; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stocktake_counts (id, "sessionId", "itemId", "lotId", "qtyCounted", "countedById", "countedAt") FROM stdin;
\.


--
-- Data for Name: stocktake_sessions; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stocktake_sessions (id, "sessionNumber", "warehouseId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: stocktake_snapshots; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stocktake_snapshots (id, "sessionId", "itemId", "lotId", "qtySnapshot", "wacSnapshot", "createdAt") FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.suppliers (id, name, code, "contactEmail", version, "contactName", "contactPhone", "isActive") FROM stdin;
71c4f0e9-8e36-47dc-a4ef-ffc6f2af4b82	Global Food Supplies	SUP-001	supplier1@example.com	1	John Doe	+1234567890	t
2c8431eb-2312-4cff-a4d1-0293b3e958a3	Fresh Dairy Co	SUP-002	supplier2@example.com	1	Jane Smith	+0987654321	t
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.system_settings (key, value, version, "createdAt", "updatedAt") FROM stdin;
system_settings	{"system_name":"LogiRest System","base_currency":"SAR","branch_id":"HQ","timezone":"Asia/Riyadh","locale_default":"en","sender_name":"LogiRest Alerts","reply_to_email":"alerts@logirest.app","mail_provider":"smtp","smtp_host":"","smtp_port":587,"smtp_user":"","smtp_password":"","smtp_encryption":"tls"}	1	2026-05-29 19:41:42.332	2026-05-30 17:56:55.131
last_backup_at	2026-05-30T19:14:53.960Z	1	2026-05-30 19:14:53.961	2026-05-30 19:14:53.961
\.


--
-- Data for Name: transfer_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.transfer_lines (id, "transferId", "itemId", "quantityShipped", "quantityReceived", "varianceReason") FROM stdin;
\.


--
-- Data for Name: transfers; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.transfers (id, "transferNumber", "fromWarehouseId", "toWarehouseId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: units_of_measure; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.units_of_measure (id, name, code, version) FROM stdin;
5b6948e9-220a-4c2a-9264-7486f6d52a00	Kilogram	KG	1
a1569c95-06ea-4d69-81df-83b382491849	Liter	LTR	1
3b37b5b7-fdc9-49e3-879a-1350979b606e	Piece	PCS	1
5de39514-6462-471b-95ac-134dc2920e92	Gram	G	1
21b4128b-e90a-45e7-9d15-30a77b8555bd	Milliliter	ML	1
06ecbd6c-755c-4940-bfb1-77825363d6c0	Pack	PK	1
3e0bf9fd-217e-4a51-ac73-6ff49ed165cf	Box	BOX	1
f9e5e76b-5ff8-44d7-95ff-b7e9c29692c3	Carton	CTN	1
b14c2b55-812b-41ef-a11f-305ef617a804	Dozen	DZ	1
ba184627-b3d8-4fcb-bb77-01314ddc038e	Pound	LB	1
\.


--
-- Data for Name: user_warehouse_scopes; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.user_warehouse_scopes (id, "userId", "warehouseId", version) FROM stdin;
cbb667f1-cc4b-49b5-8c0f-e594a1f4b7b1	650501a7-3e78-4d4e-bf8e-f8100e157f2c	d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	1
f9ed8c6f-d81f-4422-8bdf-4c2cf85e2c9e	ce9db054-47a8-4651-ad5b-117ffd5f3558	d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	1
a29a4d71-0572-4efa-8812-e10df263e73e	c8142c2a-7916-48d0-8d01-5af8c86b80b6	d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.users (id, email, "passwordHash", name, role, "isActive", version, "createdAt", "updatedAt", failed_login_attempts, locked_until) FROM stdin;
ce9db054-47a8-4651-ad5b-117ffd5f3558	manager@logirest.local	$2b$12$I6O5oXAmz7lL74icxvAKZeLjPehdE8ad6TXz6gIzvdwLYPGC5cbii	Inventory Manager	INV_MGR	t	1	2026-05-29 19:41:45.97	2026-05-29 19:41:45.97	0	\N
c8142c2a-7916-48d0-8d01-5af8c86b80b6	admin@logirest.com	$2b$10$tZH4.s/Ghlmulj4JqY.nceP4kl28oxwwowuyrp5FhsPL/nRW.2xa2	System Admin Com	ADMIN	t	1	2026-05-29 19:41:45.959	2026-05-30 18:53:22.036	1	\N
650501a7-3e78-4d4e-bf8e-f8100e157f2c	admin@logirest.local	$2b$12$I6O5oXAmz7lL74icxvAKZeLjPehdE8ad6TXz6gIzvdwLYPGC5cbii	System Administrator	ADMIN	t	1	2026-05-29 19:41:45.945	2026-05-30 19:14:23.645	0	\N
\.


--
-- Data for Name: warehouse_item_lots; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.warehouse_item_lots ("warehouseId", "itemId", "lotId", "qtyOnHand", "qtyAllocated", "updatedAt") FROM stdin;
d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	bc356d01-59ac-4ae5-80c2-9db786919818	236207c7-77a3-427d-9310-d99ee2457460	500.0000	0.0000	2026-05-30 15:37:54.45
d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	054bf295-ad6f-401c-bc24-b4a58a256840	a84ff155-adf9-46a0-8608-145fbd602ce8	200.0000	0.0000	2026-05-30 15:37:54.462
\.


--
-- Data for Name: warehouse_items; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.warehouse_items ("warehouseId", "itemId", "qtyOnHand", "qtyAllocated", wac, "updatedAt", is_frozen) FROM stdin;
d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	f9ea30dc-1fc2-4f71-9db2-0e9e20a0796b	1000.0000	0.0000	6.5000	2026-05-30 15:37:54.429	f
d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	bc356d01-59ac-4ae5-80c2-9db786919818	500.0000	0.0000	12.0000	2026-05-30 15:37:54.446	f
d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	054bf295-ad6f-401c-bc24-b4a58a256840	200.0000	0.0000	4.5000	2026-05-30 15:37:54.459	f
\.


--
-- Data for Name: warehouse_locks; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.warehouse_locks (id, "warehouseId", "lockType", "lockedById", "expiresAt", "createdAt", "isActive", status) FROM stdin;
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.warehouses (id, "branchId", name, code, "isLocked", version, "createdAt", "isActive") FROM stdin;
d77c625f-f8a1-4e7e-a4e5-194cdef1d47e	11987f31-633f-4451-bdf0-07297429be78	HQ Main Warehouse	WH-HQ-01	f	1	2026-05-29 19:41:44.21	t
c69d3219-f971-4213-b9ea-6c152eb3af48	10c0293f-c6f7-400a-bc1c-f094dc48ad4c	North Branch Warehouse	WH-NR-01	f	1	2026-05-29 19:41:44.268	t
\.


--
-- Data for Name: yield_batches; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.yield_batches (id, recipe_name, category, warehouse_id, input_qty, output_qty, waste_qty, yield_pct, standard_yield, efficiency, created_at) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: adjustment_lines adjustment_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustment_lines
    ADD CONSTRAINT adjustment_lines_pkey PRIMARY KEY (id);


--
-- Name: adjustments adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_pkey PRIMARY KEY (id);


--
-- Name: approval_events approval_events_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.approval_events
    ADD CONSTRAINT approval_events_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_archive audit_logs_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.audit_logs_archive
    ADD CONSTRAINT audit_logs_archive_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: barcode_mappings barcode_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.barcode_mappings
    ADD CONSTRAINT barcode_mappings_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cost_ledger cost_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.cost_ledger
    ADD CONSTRAINT cost_ledger_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: document_sequences document_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_pkey PRIMARY KEY (id);


--
-- Name: fx_rates fx_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT fx_rates_pkey PRIMARY KEY (id);


--
-- Name: goods_received_notes goods_received_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.goods_received_notes
    ADD CONSTRAINT goods_received_notes_pkey PRIMARY KEY (id);


--
-- Name: grn_lines grn_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.grn_lines
    ADD CONSTRAINT grn_lines_pkey PRIMARY KEY (id);


--
-- Name: idempotency_logs idempotency_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.idempotency_logs
    ADD CONSTRAINT idempotency_logs_pkey PRIMARY KEY (key);


--
-- Name: inventory_issue_lines inventory_issue_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issue_lines
    ADD CONSTRAINT inventory_issue_lines_pkey PRIMARY KEY (id);


--
-- Name: inventory_issues inventory_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issues
    ADD CONSTRAINT inventory_issues_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: kitchen_request_items kitchen_request_items_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_request_items
    ADD CONSTRAINT kitchen_request_items_pkey PRIMARY KEY (id);


--
-- Name: kitchen_requests kitchen_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_requests
    ADD CONSTRAINT kitchen_requests_pkey PRIMARY KEY (id);


--
-- Name: lot_allocations lot_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lot_allocations
    ADD CONSTRAINT lot_allocations_pkey PRIMARY KEY (id);


--
-- Name: lots lots_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT lots_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: po_lines po_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.po_lines
    ADD CONSTRAINT po_lines_pkey PRIMARY KEY (id);


--
-- Name: pr_lines pr_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.pr_lines
    ADD CONSTRAINT pr_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_requests purchase_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_pkey PRIMARY KEY (id);


--
-- Name: reconciliation_runs reconciliation_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.reconciliation_runs
    ADD CONSTRAINT reconciliation_runs_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger_archive stock_ledger_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger_archive
    ADD CONSTRAINT stock_ledger_archive_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger stock_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_pkey PRIMARY KEY (id);


--
-- Name: stocktake_counts stocktake_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT stocktake_counts_pkey PRIMARY KEY (id);


--
-- Name: stocktake_sessions stocktake_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_sessions
    ADD CONSTRAINT stocktake_sessions_pkey PRIMARY KEY (id);


--
-- Name: stocktake_snapshots stocktake_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_snapshots
    ADD CONSTRAINT stocktake_snapshots_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: transfer_lines transfer_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfer_lines
    ADD CONSTRAINT transfer_lines_pkey PRIMARY KEY (id);


--
-- Name: transfers transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_pkey PRIMARY KEY (id);


--
-- Name: units_of_measure units_of_measure_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_pkey PRIMARY KEY (id);


--
-- Name: user_warehouse_scopes user_warehouse_scopes_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.user_warehouse_scopes
    ADD CONSTRAINT user_warehouse_scopes_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouse_item_lots warehouse_item_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT warehouse_item_lots_pkey PRIMARY KEY ("warehouseId", "itemId", "lotId");


--
-- Name: warehouse_items warehouse_items_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT warehouse_items_pkey PRIMARY KEY ("warehouseId", "itemId");


--
-- Name: warehouse_locks warehouse_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_locks
    ADD CONSTRAINT warehouse_locks_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: yield_batches yield_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.yield_batches
    ADD CONSTRAINT yield_batches_pkey PRIMARY KEY (id);


--
-- Name: adjustments_adjustmentNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "adjustments_adjustmentNumber_key" ON public.adjustments USING btree ("adjustmentNumber");


--
-- Name: approval_events_documentId_documentType_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "approval_events_documentId_documentType_idx" ON public.approval_events USING btree ("documentId", "documentType");


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt" DESC);


--
-- Name: audit_logs_targetTable_targetId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "audit_logs_targetTable_targetId_idx" ON public.audit_logs USING btree ("targetTable", "targetId");


--
-- Name: audit_logs_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "audit_logs_userId_createdAt_idx" ON public.audit_logs USING btree ("userId", "createdAt" DESC);


--
-- Name: barcode_mappings_barcode_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX barcode_mappings_barcode_key ON public.barcode_mappings USING btree (barcode);


--
-- Name: branches_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX branches_code_key ON public.branches USING btree (code);


--
-- Name: branches_name_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX branches_name_key ON public.branches USING btree (name);


--
-- Name: categories_name_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX categories_name_key ON public.categories USING btree (name);


--
-- Name: cost_ledger_documentId_documentType_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "cost_ledger_documentId_documentType_idx" ON public.cost_ledger USING btree ("documentId", "documentType");


--
-- Name: cost_ledger_documentId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "cost_ledger_documentId_idx" ON public.cost_ledger USING btree ("documentId");


--
-- Name: cost_ledger_idempotencyKey_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "cost_ledger_idempotencyKey_key" ON public.cost_ledger USING btree ("idempotencyKey");


--
-- Name: cost_ledger_warehouseId_itemId_postedAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "cost_ledger_warehouseId_itemId_postedAt_idx" ON public.cost_ledger USING btree ("warehouseId", "itemId", "postedAt" DESC);


--
-- Name: currencies_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX currencies_code_key ON public.currencies USING btree (code);


--
-- Name: document_sequences_document_type_year_branch_id_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX document_sequences_document_type_year_branch_id_key ON public.document_sequences USING btree (document_type, year, branch_id);


--
-- Name: fx_rates_fromCurrencyId_toCurrencyId_effectiveFrom_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "fx_rates_fromCurrencyId_toCurrencyId_effectiveFrom_idx" ON public.fx_rates USING btree ("fromCurrencyId", "toCurrencyId", "effectiveFrom" DESC);


--
-- Name: goods_received_notes_grnNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "goods_received_notes_grnNumber_key" ON public.goods_received_notes USING btree ("grnNumber");


--
-- Name: goods_received_notes_status_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX goods_received_notes_status_idx ON public.goods_received_notes USING btree (status);


--
-- Name: inventory_issues_issueNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "inventory_issues_issueNumber_key" ON public.inventory_issues USING btree ("issueNumber");


--
-- Name: items_sku_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX items_sku_key ON public.items USING btree (sku);


--
-- Name: kitchen_requests_issue_id_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX kitchen_requests_issue_id_key ON public.kitchen_requests USING btree (issue_id);


--
-- Name: kitchen_requests_requestNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "kitchen_requests_requestNumber_key" ON public.kitchen_requests USING btree ("requestNumber");


--
-- Name: lot_allocations_issueLineId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "lot_allocations_issueLineId_idx" ON public.lot_allocations USING btree ("issueLineId");


--
-- Name: lot_allocations_transferLineId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "lot_allocations_transferLineId_idx" ON public.lot_allocations USING btree ("transferLineId");


--
-- Name: lots_itemId_expiryDate_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "lots_itemId_expiryDate_idx" ON public.lots USING btree ("itemId", "expiryDate");


--
-- Name: lots_lotNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "lots_lotNumber_key" ON public.lots USING btree ("lotNumber");


--
-- Name: notification_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "notification_logs_createdAt_idx" ON public.notification_logs USING btree ("createdAt" DESC);


--
-- Name: notification_logs_targetRole_isRead_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "notification_logs_targetRole_isRead_idx" ON public.notification_logs USING btree ("targetRole", "isRead");


--
-- Name: notification_logs_warehouseId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "notification_logs_warehouseId_idx" ON public.notification_logs USING btree ("warehouseId");


--
-- Name: outbox_events_status_createdAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "outbox_events_status_createdAt_idx" ON public.outbox_events USING btree (status, "createdAt");


--
-- Name: password_reset_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX password_reset_tokens_expires_at_idx ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: password_reset_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX password_reset_tokens_token_hash_key ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: password_reset_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX password_reset_tokens_user_id_idx ON public.password_reset_tokens USING btree (user_id);


--
-- Name: purchase_orders_poNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "purchase_orders_poNumber_key" ON public.purchase_orders USING btree ("poNumber");


--
-- Name: purchase_orders_prId_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "purchase_orders_prId_key" ON public.purchase_orders USING btree ("prId");


--
-- Name: purchase_requests_requestNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "purchase_requests_requestNumber_key" ON public.purchase_requests USING btree ("requestNumber");


--
-- Name: refresh_tokens_expiresAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "refresh_tokens_expiresAt_idx" ON public.refresh_tokens USING btree ("expiresAt");


--
-- Name: refresh_tokens_sessionId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "refresh_tokens_sessionId_idx" ON public.refresh_tokens USING btree ("sessionId");


--
-- Name: refresh_tokens_tokenHash_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "refresh_tokens_tokenHash_key" ON public.refresh_tokens USING btree ("tokenHash");


--
-- Name: refresh_tokens_userId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "refresh_tokens_userId_idx" ON public.refresh_tokens USING btree ("userId");


--
-- Name: stock_ledger_documentId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "stock_ledger_documentId_idx" ON public.stock_ledger USING btree ("documentId");


--
-- Name: stock_ledger_idempotencyKey_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "stock_ledger_idempotencyKey_key" ON public.stock_ledger USING btree ("idempotencyKey");


--
-- Name: stock_ledger_warehouseId_itemId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "stock_ledger_warehouseId_itemId_idx" ON public.stock_ledger USING btree ("warehouseId", "itemId");


--
-- Name: stock_ledger_warehouseId_itemId_postedAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "stock_ledger_warehouseId_itemId_postedAt_idx" ON public.stock_ledger USING btree ("warehouseId", "itemId", "postedAt" DESC);


--
-- Name: stocktake_sessions_sessionNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "stocktake_sessions_sessionNumber_key" ON public.stocktake_sessions USING btree ("sessionNumber");


--
-- Name: suppliers_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX suppliers_code_key ON public.suppliers USING btree (code);


--
-- Name: transfers_transferNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "transfers_transferNumber_key" ON public.transfers USING btree ("transferNumber");


--
-- Name: units_of_measure_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX units_of_measure_code_key ON public.units_of_measure USING btree (code);


--
-- Name: units_of_measure_name_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX units_of_measure_name_key ON public.units_of_measure USING btree (name);


--
-- Name: user_warehouse_scopes_userId_warehouseId_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "user_warehouse_scopes_userId_warehouseId_key" ON public.user_warehouse_scopes USING btree ("userId", "warehouseId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: warehouse_item_lots_warehouseId_itemId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "warehouse_item_lots_warehouseId_itemId_idx" ON public.warehouse_item_lots USING btree ("warehouseId", "itemId");


--
-- Name: warehouse_locks_isActive_expiresAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "warehouse_locks_isActive_expiresAt_idx" ON public.warehouse_locks USING btree ("isActive", "expiresAt");


--
-- Name: warehouse_locks_warehouseId_isActive_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "warehouse_locks_warehouseId_isActive_idx" ON public.warehouse_locks USING btree ("warehouseId", "isActive");


--
-- Name: warehouses_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX warehouses_code_key ON public.warehouses USING btree (code);


--
-- Name: yield_batches_warehouse_id_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX yield_batches_warehouse_id_idx ON public.yield_batches USING btree (warehouse_id);


--
-- Name: adjustment_lines adjustment_lines_adjustmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustment_lines
    ADD CONSTRAINT "adjustment_lines_adjustmentId_fkey" FOREIGN KEY ("adjustmentId") REFERENCES public.adjustments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: adjustment_lines adjustment_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustment_lines
    ADD CONSTRAINT "adjustment_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: adjustment_lines adjustment_lines_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustment_lines
    ADD CONSTRAINT "adjustment_lines_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: adjustments adjustments_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT "adjustments_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_events approval_events_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.approval_events
    ADD CONSTRAINT "approval_events_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: barcode_mappings barcode_mappings_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.barcode_mappings
    ADD CONSTRAINT "barcode_mappings_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cost_ledger cost_ledger_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.cost_ledger
    ADD CONSTRAINT "cost_ledger_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cost_ledger cost_ledger_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.cost_ledger
    ADD CONSTRAINT "cost_ledger_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: departments departments_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT "departments_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public.branches(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_sequences document_sequences_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fx_rates fx_rates_fromCurrencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT "fx_rates_fromCurrencyId_fkey" FOREIGN KEY ("fromCurrencyId") REFERENCES public.currencies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fx_rates fx_rates_toCurrencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT "fx_rates_toCurrencyId_fkey" FOREIGN KEY ("toCurrencyId") REFERENCES public.currencies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_received_notes goods_received_notes_poId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.goods_received_notes
    ADD CONSTRAINT "goods_received_notes_poId_fkey" FOREIGN KEY ("poId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_received_notes goods_received_notes_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.goods_received_notes
    ADD CONSTRAINT "goods_received_notes_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: grn_lines grn_lines_grnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.grn_lines
    ADD CONSTRAINT "grn_lines_grnId_fkey" FOREIGN KEY ("grnId") REFERENCES public.goods_received_notes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grn_lines grn_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.grn_lines
    ADD CONSTRAINT "grn_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: grn_lines grn_lines_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.grn_lines
    ADD CONSTRAINT "grn_lines_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: inventory_issue_lines inventory_issue_lines_issueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issue_lines
    ADD CONSTRAINT "inventory_issue_lines_issueId_fkey" FOREIGN KEY ("issueId") REFERENCES public.inventory_issues(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_issue_lines inventory_issue_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issue_lines
    ADD CONSTRAINT "inventory_issue_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inventory_issues inventory_issues_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issues
    ADD CONSTRAINT "inventory_issues_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inventory_issues inventory_issues_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issues
    ADD CONSTRAINT "inventory_issues_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: items items_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT "items_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: items items_uomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT "items_uomId_fkey" FOREIGN KEY ("uomId") REFERENCES public.units_of_measure(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kitchen_request_items kitchen_request_items_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_request_items
    ADD CONSTRAINT "kitchen_request_items_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kitchen_request_items kitchen_request_items_requestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_request_items
    ADD CONSTRAINT "kitchen_request_items_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES public.kitchen_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kitchen_requests kitchen_requests_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_requests
    ADD CONSTRAINT "kitchen_requests_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kitchen_requests kitchen_requests_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_requests
    ADD CONSTRAINT kitchen_requests_issue_id_fkey FOREIGN KEY (issue_id) REFERENCES public.inventory_issues(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: kitchen_requests kitchen_requests_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_requests
    ADD CONSTRAINT "kitchen_requests_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lot_allocations lot_allocations_issueLineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lot_allocations
    ADD CONSTRAINT "lot_allocations_issueLineId_fkey" FOREIGN KEY ("issueLineId") REFERENCES public.inventory_issue_lines(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lot_allocations lot_allocations_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lot_allocations
    ADD CONSTRAINT "lot_allocations_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lot_allocations lot_allocations_transferLineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lot_allocations
    ADD CONSTRAINT "lot_allocations_transferLineId_fkey" FOREIGN KEY ("transferLineId") REFERENCES public.transfer_lines(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lots lots_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT "lots_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: po_lines po_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.po_lines
    ADD CONSTRAINT "po_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: po_lines po_lines_poId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.po_lines
    ADD CONSTRAINT "po_lines_poId_fkey" FOREIGN KEY ("poId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pr_lines pr_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.pr_lines
    ADD CONSTRAINT "pr_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pr_lines pr_lines_prId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.pr_lines
    ADD CONSTRAINT "pr_lines_prId_fkey" FOREIGN KEY ("prId") REFERENCES public.purchase_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_currencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_currencyId_fkey" FOREIGN KEY ("currencyId") REFERENCES public.currencies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_orders purchase_orders_prId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_prId_fkey" FOREIGN KEY ("prId") REFERENCES public.purchase_requests(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_requests purchase_requests_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT "purchase_requests_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public.branches(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_requests purchase_requests_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT "purchase_requests_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_requests purchase_requests_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT "purchase_requests_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refresh_tokens refresh_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_ledger stock_ledger_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT "stock_ledger_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_ledger stock_ledger_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT "stock_ledger_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_ledger stock_ledger_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT "stock_ledger_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_counts stocktake_counts_countedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT "stocktake_counts_countedById_fkey" FOREIGN KEY ("countedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_counts stocktake_counts_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT "stocktake_counts_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_counts stocktake_counts_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT "stocktake_counts_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_counts stocktake_counts_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT "stocktake_counts_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.stocktake_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stocktake_sessions stocktake_sessions_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_sessions
    ADD CONSTRAINT "stocktake_sessions_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_snapshots stocktake_snapshots_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_snapshots
    ADD CONSTRAINT "stocktake_snapshots_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_snapshots stocktake_snapshots_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_snapshots
    ADD CONSTRAINT "stocktake_snapshots_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_snapshots stocktake_snapshots_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_snapshots
    ADD CONSTRAINT "stocktake_snapshots_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.stocktake_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transfer_lines transfer_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfer_lines
    ADD CONSTRAINT "transfer_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transfer_lines transfer_lines_transferId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfer_lines
    ADD CONSTRAINT "transfer_lines_transferId_fkey" FOREIGN KEY ("transferId") REFERENCES public.transfers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transfers transfers_fromWarehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT "transfers_fromWarehouseId_fkey" FOREIGN KEY ("fromWarehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transfers transfers_toWarehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT "transfers_toWarehouseId_fkey" FOREIGN KEY ("toWarehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_warehouse_scopes user_warehouse_scopes_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.user_warehouse_scopes
    ADD CONSTRAINT "user_warehouse_scopes_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_warehouse_scopes user_warehouse_scopes_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.user_warehouse_scopes
    ADD CONSTRAINT "user_warehouse_scopes_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: warehouse_item_lots warehouse_item_lots_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT "warehouse_item_lots_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_item_lots warehouse_item_lots_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT "warehouse_item_lots_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_item_lots warehouse_item_lots_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT "warehouse_item_lots_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_item_lots warehouse_item_lots_warehouseId_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT "warehouse_item_lots_warehouseId_itemId_fkey" FOREIGN KEY ("warehouseId", "itemId") REFERENCES public.warehouse_items("warehouseId", "itemId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: warehouse_items warehouse_items_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT "warehouse_items_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_items warehouse_items_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT "warehouse_items_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_locks warehouse_locks_lockedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_locks
    ADD CONSTRAINT "warehouse_locks_lockedById_fkey" FOREIGN KEY ("lockedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_locks warehouse_locks_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_locks
    ADD CONSTRAINT "warehouse_locks_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouses warehouses_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT "warehouses_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public.branches(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: yield_batches yield_batches_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.yield_batches
    ADD CONSTRAINT yield_batches_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: logirest
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict 8sH2lc4VXEDx5fhsloG78Q3UqKnaiaujgwrZNZuXkOgCZBR5ckgKXhdIjPBcwQf

