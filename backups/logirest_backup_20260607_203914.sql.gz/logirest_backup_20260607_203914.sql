--
-- PostgreSQL database dump
--

\restrict 8KichCrEKiVLsFRGx7DgGI5ntjpzv4Eww0HKIcvih0L7IRMkdov7G44IKl5DzJ1

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: AdjustmentDirection; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."AdjustmentDirection" AS ENUM (
    'IN',
    'OUT'
);


ALTER TYPE public."AdjustmentDirection" OWNER TO logirest;

--
-- Name: AdjustmentReason; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."AdjustmentReason" AS ENUM (
    'THEFT',
    'DAMAGE',
    'SPOILAGE',
    'CORRECTION',
    'ADMIN_OVERRIDE'
);


ALTER TYPE public."AdjustmentReason" OWNER TO logirest;

--
-- Name: AllocationMethod; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."AllocationMethod" AS ENUM (
    'VALUE',
    'QUANTITY',
    'WEIGHT',
    'VOLUME'
);


ALTER TYPE public."AllocationMethod" OWNER TO logirest;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."DocumentType" AS ENUM (
    'PURCHASE_REQUEST',
    'PURCHASE_ORDER',
    'GOODS_RECEIVED_NOTE',
    'INVENTORY_ISSUE',
    'TRANSFER',
    'ADJUSTMENT',
    'KITCHEN_REQUEST',
    'STOCKTAKE'
);


ALTER TYPE public."DocumentType" OWNER TO logirest;

--
-- Name: LandedCostStatus; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."LandedCostStatus" AS ENUM (
    'DRAFT',
    'PROCESSING',
    'POSTED'
);


ALTER TYPE public."LandedCostStatus" OWNER TO logirest;

--
-- Name: LockStatus; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."LockStatus" AS ENUM (
    'ACTIVE',
    'STALE',
    'RELEASED'
);


ALTER TYPE public."LockStatus" OWNER TO logirest;

--
-- Name: LockType; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."LockType" AS ENUM (
    'STOCKTAKE',
    'MANUAL'
);


ALTER TYPE public."LockType" OWNER TO logirest;

--
-- Name: LotStatus; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."LotStatus" AS ENUM (
    'ACTIVE',
    'HOLD',
    'EXPIRED',
    'QUARANTINE'
);


ALTER TYPE public."LotStatus" OWNER TO logirest;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'GM',
    'INV_MGR',
    'WH_KEEPER',
    'PROC_OFFICER',
    'APPROVER',
    'AUDITOR',
    'VIEWER',
    'KITCHEN_CHIEF',
    'STORE_MGR'
);


ALTER TYPE public."Role" OWNER TO logirest;

--
-- Name: StocktakeStatus; Type: TYPE; Schema: public; Owner: logirest
--

CREATE TYPE public."StocktakeStatus" AS ENUM (
    'DRAFT',
    'STARTED',
    'COUNTING',
    'REVIEW',
    'APPROVED',
    'POSTED',
    'CLOSED',
    'CANCELLED'
);


ALTER TYPE public."StocktakeStatus" OWNER TO logirest;

--
-- Name: prevent_ledger_mutation(); Type: FUNCTION; Schema: public; Owner: logirest
--

CREATE FUNCTION public.prevent_ledger_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Ledger tables are immutable and cannot be modified';
END;
$$;


ALTER FUNCTION public.prevent_ledger_mutation() OWNER TO logirest;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO logirest;

--
-- Name: adjustment_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.adjustment_lines (
    id text NOT NULL,
    "adjustmentId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    quantity numeric(18,4) NOT NULL,
    direction public."AdjustmentDirection" NOT NULL,
    reason public."AdjustmentReason" NOT NULL,
    "unitCost" numeric(18,4)
);


ALTER TABLE public.adjustment_lines OWNER TO logirest;

--
-- Name: adjustments; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.adjustments (
    id text NOT NULL,
    "adjustmentNumber" text NOT NULL,
    "warehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.adjustments OWNER TO logirest;

--
-- Name: approval_events; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.approval_events (
    id text NOT NULL,
    "documentId" text NOT NULL,
    "documentType" public."DocumentType" NOT NULL,
    "fromStatus" text NOT NULL,
    "toStatus" text NOT NULL,
    "actionPerformed" text NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments text,
    "stepNumber" integer NOT NULL,
    "userRole" public."Role" NOT NULL
);


ALTER TABLE public.approval_events OWNER TO logirest;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    "targetTable" text NOT NULL,
    "targetId" text NOT NULL,
    "beforeStateJson" text NOT NULL,
    "afterStateJson" text NOT NULL,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO logirest;

--
-- Name: audit_logs_archive; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.audit_logs_archive (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    "targetTable" text NOT NULL,
    "targetId" text NOT NULL,
    "beforeStateJson" text NOT NULL,
    "afterStateJson" text NOT NULL,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone NOT NULL,
    integrity_hash character varying(64)
);


ALTER TABLE public.audit_logs_archive OWNER TO logirest;

--
-- Name: barcode_mappings; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.barcode_mappings (
    id text NOT NULL,
    "itemId" text NOT NULL,
    barcode text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.barcode_mappings OWNER TO logirest;

--
-- Name: branches; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.branches (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.branches OWNER TO logirest;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.categories OWNER TO logirest;

--
-- Name: cost_ledger; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.cost_ledger (
    id text NOT NULL,
    "postedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    quantity numeric(18,4) NOT NULL,
    "unitPrice" numeric(18,4) NOT NULL,
    "newWac" numeric(18,4) NOT NULL,
    "documentId" text NOT NULL,
    "documentType" public."DocumentType" NOT NULL,
    "idempotencyKey" text NOT NULL,
    archived_at timestamp(3) without time zone
);


ALTER TABLE public.cost_ledger OWNER TO logirest;

--
-- Name: cost_ledger_archive; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.cost_ledger_archive (
    id text NOT NULL,
    "postedAt" timestamp(3) without time zone NOT NULL,
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    quantity numeric(18,4) NOT NULL,
    "unitPrice" numeric(18,4) NOT NULL,
    "newWac" numeric(18,4) NOT NULL,
    "documentId" text NOT NULL,
    "documentType" public."DocumentType" NOT NULL,
    "idempotencyKey" text,
    integrity_hash character varying(64)
);


ALTER TABLE public.cost_ledger_archive OWNER TO logirest;

--
-- Name: currencies; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.currencies (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    "isBase" boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.currencies OWNER TO logirest;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.departments (
    id text NOT NULL,
    "branchId" text NOT NULL,
    name text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.departments OWNER TO logirest;

--
-- Name: document_counters; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.document_counters (
    doc_type text NOT NULL,
    last_seq integer DEFAULT 0 NOT NULL,
    branch_code text NOT NULL,
    year integer NOT NULL
);


ALTER TABLE public.document_counters OWNER TO logirest;

--
-- Name: document_sequences; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.document_sequences (
    id text NOT NULL,
    branch_id text NOT NULL,
    document_type public."DocumentType" NOT NULL,
    year integer NOT NULL,
    current_sequence integer DEFAULT 0 NOT NULL,
    prefix text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.document_sequences OWNER TO logirest;

--
-- Name: fx_rates; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.fx_rates (
    id text NOT NULL,
    "fromCurrencyId" text NOT NULL,
    "toCurrencyId" text NOT NULL,
    rate numeric(18,6) NOT NULL,
    "effectiveFrom" timestamp(3) without time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.fx_rates OWNER TO logirest;

--
-- Name: goods_received_notes; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.goods_received_notes (
    id text NOT NULL,
    "grnNumber" text NOT NULL,
    "poId" text NOT NULL,
    "warehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.goods_received_notes OWNER TO logirest;

--
-- Name: grn_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.grn_lines (
    id text NOT NULL,
    "grnId" text NOT NULL,
    "itemId" text NOT NULL,
    "quantityReceived" numeric(18,4) NOT NULL,
    "unitPrice" numeric(18,4) NOT NULL,
    "lotId" text
);


ALTER TABLE public.grn_lines OWNER TO logirest;

--
-- Name: idempotency_logs; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.idempotency_logs (
    key text NOT NULL,
    "responseBody" text NOT NULL,
    "statusCode" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.idempotency_logs OWNER TO logirest;

--
-- Name: inventory_issue_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.inventory_issue_lines (
    id text NOT NULL,
    "issueId" text NOT NULL,
    "itemId" text NOT NULL,
    quantity numeric(18,4) NOT NULL
);


ALTER TABLE public.inventory_issue_lines OWNER TO logirest;

--
-- Name: inventory_issues; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.inventory_issues (
    id text NOT NULL,
    "issueNumber" text NOT NULL,
    "warehouseId" text NOT NULL,
    "departmentId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.inventory_issues OWNER TO logirest;

--
-- Name: items; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.items (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    "uomId" text NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    "isBatched" boolean DEFAULT false NOT NULL,
    "hasExpiry" boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "reorderPoint" numeric(18,4)
);


ALTER TABLE public.items OWNER TO logirest;

--
-- Name: kitchen_request_items; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.kitchen_request_items (
    id text NOT NULL,
    "requestId" text NOT NULL,
    "itemId" text NOT NULL,
    "quantityRequested" numeric(18,4) NOT NULL,
    "quantityFulfilled" numeric(18,4) NOT NULL,
    CONSTRAINT chk_quantity_fulfilled_non_negative CHECK (("quantityFulfilled" >= (0)::numeric))
);


ALTER TABLE public.kitchen_request_items OWNER TO logirest;

--
-- Name: kitchen_requests; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.kitchen_requests (
    id text NOT NULL,
    "requestNumber" text NOT NULL,
    "departmentId" text NOT NULL,
    "warehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    issue_id text
);


ALTER TABLE public.kitchen_requests OWNER TO logirest;

--
-- Name: landed_cost_allocation_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.landed_cost_allocation_lines (
    id text NOT NULL,
    "landedCostVoucherId" text NOT NULL,
    "grnLineId" text NOT NULL,
    "allocatedCost" numeric(18,4) NOT NULL,
    "adjustedUnitCost" numeric(18,4) NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.landed_cost_allocation_lines OWNER TO logirest;

--
-- Name: landed_cost_grn_relations; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.landed_cost_grn_relations (
    id text NOT NULL,
    "landedCostVoucherId" text NOT NULL,
    "grnId" text NOT NULL
);


ALTER TABLE public.landed_cost_grn_relations OWNER TO logirest;

--
-- Name: landed_cost_vouchers; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.landed_cost_vouchers (
    id text NOT NULL,
    "voucherNumber" text NOT NULL,
    "allocationMethod" public."AllocationMethod" NOT NULL,
    "totalAllocatedCost" numeric(18,4) NOT NULL,
    status public."LandedCostStatus" DEFAULT 'DRAFT'::public."LandedCostStatus" NOT NULL,
    "currencyId" text NOT NULL,
    "exchangeRate" numeric(18,6) DEFAULT 1.0 NOT NULL,
    "transactionDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdById" text NOT NULL
);


ALTER TABLE public.landed_cost_vouchers OWNER TO logirest;

--
-- Name: lot_allocations; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.lot_allocations (
    id text NOT NULL,
    "issueLineId" text,
    "transferLineId" text,
    "lotId" text NOT NULL,
    "quantityAllocated" numeric(18,4) NOT NULL
);


ALTER TABLE public.lot_allocations OWNER TO logirest;

--
-- Name: lots; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.lots (
    id text NOT NULL,
    "itemId" text NOT NULL,
    "lotNumber" text NOT NULL,
    "receivedDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiryDate" timestamp(3) without time zone,
    status public."LotStatus" DEFAULT 'ACTIVE'::public."LotStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lots OWNER TO logirest;

--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.notification_logs (
    id text NOT NULL,
    "targetRole" public."Role" NOT NULL,
    "warehouseId" text,
    message text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "documentType" public."DocumentType",
    "documentId" text
);


ALTER TABLE public.notification_logs OWNER TO logirest;

--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.outbox_events (
    id text NOT NULL,
    "eventType" text NOT NULL,
    payload jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "lastError" text,
    "processedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "documentId" text,
    event_hash character varying(64),
    dead_lettered boolean DEFAULT false NOT NULL,
    retry_history jsonb,
    CONSTRAINT outbox_events_status_valid CHECK ((status = ANY (ARRAY['PENDING'::text, 'SUCCEEDED'::text, 'FAILED'::text])))
);


ALTER TABLE public.outbox_events OWNER TO logirest;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.password_reset_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    used_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO logirest;

--
-- Name: po_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.po_lines (
    id text NOT NULL,
    "poId" text NOT NULL,
    "itemId" text NOT NULL,
    quantity numeric(18,4) NOT NULL,
    "unitPrice" numeric(18,4) NOT NULL
);


ALTER TABLE public.po_lines OWNER TO logirest;

--
-- Name: pr_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.pr_lines (
    id text NOT NULL,
    "prId" text NOT NULL,
    "itemId" text NOT NULL,
    quantity numeric(18,4) NOT NULL
);


ALTER TABLE public.pr_lines OWNER TO logirest;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.purchase_orders (
    id text NOT NULL,
    "poNumber" text NOT NULL,
    "prId" text,
    "supplierId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "currencyId" text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.purchase_orders OWNER TO logirest;

--
-- Name: purchase_requests; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.purchase_requests (
    id text NOT NULL,
    "requestNumber" text NOT NULL,
    "branchId" text NOT NULL,
    "warehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "createdById" text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.purchase_requests OWNER TO logirest;

--
-- Name: reconciliation_runs; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.reconciliation_runs (
    id text NOT NULL,
    "ranAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "itemsChecked" integer NOT NULL,
    "discrepanciesFound" integer NOT NULL,
    "frozenItems" text[],
    "durationMs" integer NOT NULL,
    lot_discrepancies_found integer DEFAULT 0 NOT NULL,
    wac_drift_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.reconciliation_runs OWNER TO logirest;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    "tokenHash" text NOT NULL,
    "userId" text NOT NULL,
    "sessionId" text NOT NULL,
    "parentTokenId" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "isRevoked" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO logirest;

--
-- Name: stock_ledger; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stock_ledger (
    id text NOT NULL,
    "postedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    quantity numeric(18,4) NOT NULL,
    "documentId" text NOT NULL,
    "documentType" public."DocumentType" NOT NULL,
    "idempotencyKey" text NOT NULL
);


ALTER TABLE public.stock_ledger OWNER TO logirest;

--
-- Name: stock_ledger_archive; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stock_ledger_archive (
    id text NOT NULL,
    "postedAt" timestamp(3) without time zone NOT NULL,
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    quantity numeric(18,4) NOT NULL,
    "documentId" text NOT NULL,
    "documentType" public."DocumentType" NOT NULL,
    "idempotencyKey" text,
    cost_ledger_entries jsonb,
    integrity_hash character varying(64)
);


ALTER TABLE public.stock_ledger_archive OWNER TO logirest;

--
-- Name: stocktake_counts; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stocktake_counts (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    "qtyCounted" numeric(18,4) NOT NULL,
    "countedById" text NOT NULL,
    "countedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stocktake_counts OWNER TO logirest;

--
-- Name: stocktake_sessions; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stocktake_sessions (
    id text NOT NULL,
    "sessionNumber" text NOT NULL,
    "warehouseId" text NOT NULL,
    status public."StocktakeStatus" DEFAULT 'DRAFT'::public."StocktakeStatus" NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stocktake_sessions OWNER TO logirest;

--
-- Name: stocktake_snapshots; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.stocktake_snapshots (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text,
    "qtySnapshot" numeric(18,4) NOT NULL,
    "wacSnapshot" numeric(18,4) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stocktake_snapshots OWNER TO logirest;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    "contactEmail" text,
    version integer DEFAULT 1 NOT NULL,
    "contactName" text,
    "contactPhone" text,
    "isActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.suppliers OWNER TO logirest;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.system_settings (
    key text NOT NULL,
    value text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.system_settings OWNER TO logirest;

--
-- Name: transfer_lines; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.transfer_lines (
    id text NOT NULL,
    "transferId" text NOT NULL,
    "itemId" text NOT NULL,
    "quantityShipped" numeric(18,4) NOT NULL,
    "quantityReceived" numeric(18,4),
    "varianceReason" text,
    "unitCost" numeric(18,4)
);


ALTER TABLE public.transfer_lines OWNER TO logirest;

--
-- Name: transfers; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.transfers (
    id text NOT NULL,
    "transferNumber" text NOT NULL,
    "fromWarehouseId" text NOT NULL,
    "toWarehouseId" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transfers OWNER TO logirest;

--
-- Name: units_of_measure; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.units_of_measure (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.units_of_measure OWNER TO logirest;

--
-- Name: user_warehouse_scopes; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.user_warehouse_scopes (
    id text NOT NULL,
    "userId" text NOT NULL,
    "warehouseId" text NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.user_warehouse_scopes OWNER TO logirest;

--
-- Name: users; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    name text NOT NULL,
    role public."Role" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp(3) without time zone
);


ALTER TABLE public.users OWNER TO logirest;

--
-- Name: warehouse_item_lots; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.warehouse_item_lots (
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    "lotId" text NOT NULL,
    "qtyOnHand" numeric(18,4) DEFAULT 0 NOT NULL,
    "qtyAllocated" numeric(18,4) DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    CONSTRAINT chk_lot_qty_on_hand_non_negative CHECK (("qtyOnHand" >= (0)::numeric)),
    CONSTRAINT chk_qty_non_negative CHECK (("qtyOnHand" >= (0)::numeric)),
    CONSTRAINT warehouse_item_lots_qty_on_hand_nonneg CHECK (("qtyOnHand" >= (0)::numeric))
);


ALTER TABLE public.warehouse_item_lots OWNER TO logirest;

--
-- Name: warehouse_items; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.warehouse_items (
    "warehouseId" text NOT NULL,
    "itemId" text NOT NULL,
    "qtyOnHand" numeric(18,4) DEFAULT 0 NOT NULL,
    "qtyAllocated" numeric(18,4) DEFAULT 0 NOT NULL,
    wac numeric(18,4) DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    is_frozen boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_qty_on_hand_non_negative CHECK (("qtyOnHand" >= (0)::numeric)),
    CONSTRAINT warehouse_items_qty_allocated_nonneg CHECK (("qtyAllocated" >= (0)::numeric)),
    CONSTRAINT warehouse_items_qty_on_hand_nonneg CHECK (("qtyOnHand" >= (0)::numeric))
);


ALTER TABLE public.warehouse_items OWNER TO logirest;

--
-- Name: warehouse_locks; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.warehouse_locks (
    id text NOT NULL,
    "warehouseId" text NOT NULL,
    "lockType" public."LockType" NOT NULL,
    "lockedById" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    status public."LockStatus" DEFAULT 'ACTIVE'::public."LockStatus" NOT NULL
);


ALTER TABLE public.warehouse_locks OWNER TO logirest;

--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.warehouses (
    id text NOT NULL,
    "branchId" text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    "isLocked" boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.warehouses OWNER TO logirest;

--
-- Name: yield_batches; Type: TABLE; Schema: public; Owner: logirest
--

CREATE TABLE public.yield_batches (
    id text NOT NULL,
    recipe_name text NOT NULL,
    category text NOT NULL,
    warehouse_id text,
    input_qty double precision NOT NULL,
    output_qty double precision NOT NULL,
    waste_qty double precision NOT NULL,
    yield_pct double precision NOT NULL,
    standard_yield double precision NOT NULL,
    efficiency double precision NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.yield_batches OWNER TO logirest;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
04d5ae52-c459-45f4-89b0-ba59adda16a6	a27a4f61f79b950e03cc285c3077a713b81ed1d2260a81f9199f27169bd69fc1	2026-06-07 20:39:50.948326+00	0001_init	\N	\N	2026-06-07 20:39:49.813868+00	1
0985feed-79b8-4703-8453-0ee3160be153	b061a8f95ee448344fe5abdb1bf68a6a97d2b48eae9b0feffa5bf1fd3b6f4e51	2026-06-07 20:39:51.315586+00	20260530172800_add_qty_on_hand_check	\N	\N	2026-06-07 20:39:51.310061+00	1
bf82c415-752a-4ae2-9c99-d127e3877a1c	5bcff1398948809884901b5337e62f1d44cd76badc342959ab06e95f45763f13	2026-06-07 20:39:50.994856+00	20260523204900_drift_delta_hardening	\N	\N	2026-06-07 20:39:50.950231+00	1
5f23383c-9de4-40a8-90d7-12480d9f350c	5d07efc92ba1812887899f83edc274cf01a9a2e3b8510db6c56092338aff62ad	2026-06-07 20:39:51.027207+00	20260524000000_add_document_sequence_and_is_frozen	\N	\N	2026-06-07 20:39:50.996574+00	1
4620c208-c7e3-4104-ad42-443863a6444b	62dc08c9b0950e1076f0377f4b876d5d255cdd13ac0236860c761565c799d869	2026-06-07 20:39:51.061361+00	20260524020000_sprint1_add_indexes	\N	\N	2026-06-07 20:39:51.028976+00	1
7855c9b8-27cc-4df1-b8f1-5b0b50c7b1e3	fac7ae4b4c3d5a1381b73b56cd4afb9d26bcf63fc6e16b34f1a8f4e04df16144	2026-06-07 20:39:51.329258+00	20260531185500_add_fx_rate_unique_and_transfer_unit_cost	\N	\N	2026-06-07 20:39:51.317304+00	1
ca0a16c4-75e8-430d-9f31-617aec134430	380c240522ddb59bd6e768f9984bb278aac14245caf0ca5f962d850238f569e7	2026-06-07 20:39:51.071104+00	20260525000000_extend_supplier_model	\N	\N	2026-06-07 20:39:51.063754+00	1
d2818887-ed8f-4787-a93e-9e8c550b37ff	d5e75a151393b1e50d761b570524dd6bc8ce378fcae3a68b42caf71ddaa93564	2026-06-07 20:39:51.110186+00	20260525024637_add_reorder_point	\N	\N	2026-06-07 20:39:51.073888+00	1
9f792405-5518-4d67-b31c-21b80a403151	a96059be9881de4745cdc0070e978dc014c3c8ce1aa7a9c240366c3f324750e5	2026-06-07 20:39:51.125216+00	20260525172054_add_nonneg_qty_constraints	\N	\N	2026-06-07 20:39:51.116577+00	1
45e5bef8-332f-4ff3-8292-d42a13c6ded7	9c6de6bfd8ef3e4b9a3fa81446b9176fb19f9ec45fbe3a56a1038fcdcc81dca2	2026-06-07 20:39:51.395557+00	20260602111209_add_cost_ledger_archive_and_harden_idempotency_keys	\N	\N	2026-06-07 20:39:51.331232+00	1
c857910a-0665-4f12-81e5-0e70917f02d0	b9e93edcc7cb652d23e60d5474c666002bbcd8163795d8ba1fa43894d7f03637	2026-06-07 20:39:51.144289+00	20260525222604_add_system_settings_and_optional_audit_log	\N	\N	2026-06-07 20:39:51.126974+00	1
ccc5fe92-c4bc-45f9-ac05-b9e568bcde8d	9e477efb1f78a632f9ea1e11a25efc2466be4bbbb2325bb82b01f190b36e88af	2026-06-07 20:39:51.178312+00	20260526015529_add_archival_tables	\N	\N	2026-06-07 20:39:51.151274+00	1
687dd8bb-8ced-4607-9276-71e638c90c99	39e4fc89c6150b7f938a9d688728e9f6f3f973118abaeb9a1c213b868610f5e1	2026-06-07 20:39:51.184606+00	20260526163716_add_nonneg_qty_constraints	\N	\N	2026-06-07 20:39:51.180252+00	1
f2b706f6-1c81-46e1-9c04-92e6e52e1b9a	fa4750c40945a89a8c6270b58d9161b08a7c9f6c72e685247b797b2e20e77fcb	2026-06-07 20:39:51.414556+00	20260602111307_protect_ledger_tables	\N	\N	2026-06-07 20:39:51.3972+00	1
3e6e33a6-55c3-41e0-b904-1232f6caa677	44f6ca919d33a8b4b833e4e74a5bfe294751fccfad091fdcbcf27e7e9ea8d90a	2026-06-07 20:39:51.202177+00	20260527000000_add_production_indexes	\N	\N	2026-06-07 20:39:51.18624+00	1
037e15d5-eb91-4542-bd22-bdc1facf56f6	f2184d213b99cbd7120940097c4a14aa71f116666a9393aa7a2e17bb1cd77604	2026-06-07 20:39:51.21818+00	20260528210535_add_workflow_query_indexes	\N	\N	2026-06-07 20:39:51.203886+00	1
9af29e1e-f421-4650-87e3-c6d1e06cd087	8314a3ec3557c7dcc0d1ff5a57fa05dfdd1a8e592cc7784c256b6f4a97a1f607	2026-06-07 20:39:51.308298+00	20260530034500_risk_remediation_changes	\N	\N	2026-06-07 20:39:51.219911+00	1
68b6a046-0b92-4155-a5b9-543f0fc1699b	fd7aad3ee6e99e299fac2cceb2bd69cba10e7e3b803cb5909cb89cce5ae4a07c	2026-06-07 20:39:51.4406+00	20260603145618_add_document_counter	\N	\N	2026-06-07 20:39:51.416339+00	1
e38312e9-097e-4c51-b239-f2fb234964a0	52a650a105725e3f1389017f331f2efa61d867d9a260294a58e615fa6e167086	2026-06-07 20:39:51.46375+00	20260603160117_add_outbox_event_hash	\N	\N	2026-06-07 20:39:51.443088+00	1
80b3664d-ddf6-47d8-adbd-6c47810e7a08	12f3385313b88f46749ef4991543a9749bf4438a312cc1a771f18ba88b77b593	2026-06-07 20:39:51.470642+00	20260603213356_add_wac_drift_count	\N	\N	2026-06-07 20:39:51.465409+00	1
65d4319b-29ce-425b-9063-a66eba135baa	f1ae0b70793d6619a7631d28449e834e447c00c180550971b9e309c2aa8b7df0	2026-06-07 20:39:51.637296+00	20260603225452_hardening_sprint4	\N	\N	2026-06-07 20:39:51.472458+00	1
\.


--
-- Data for Name: adjustment_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.adjustment_lines (id, "adjustmentId", "itemId", "lotId", quantity, direction, reason, "unitCost") FROM stdin;
\.


--
-- Data for Name: adjustments; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.adjustments (id, "adjustmentNumber", "warehouseId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: approval_events; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.approval_events (id, "documentId", "documentType", "fromStatus", "toStatus", "actionPerformed", "userId", "createdAt", comments, "stepNumber", "userRole") FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.audit_logs (id, "userId", action, "targetTable", "targetId", "beforeStateJson", "afterStateJson", "ipAddress", "createdAt") FROM stdin;
\.


--
-- Data for Name: audit_logs_archive; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.audit_logs_archive (id, "userId", action, "targetTable", "targetId", "beforeStateJson", "afterStateJson", "ipAddress", "createdAt", integrity_hash) FROM stdin;
\.


--
-- Data for Name: barcode_mappings; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.barcode_mappings (id, "itemId", barcode, version) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.branches (id, name, code, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.categories (id, name, version) FROM stdin;
\.


--
-- Data for Name: cost_ledger; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.cost_ledger (id, "postedAt", "warehouseId", "itemId", quantity, "unitPrice", "newWac", "documentId", "documentType", "idempotencyKey", archived_at) FROM stdin;
\.


--
-- Data for Name: cost_ledger_archive; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.cost_ledger_archive (id, "postedAt", "warehouseId", "itemId", quantity, "unitPrice", "newWac", "documentId", "documentType", "idempotencyKey", integrity_hash) FROM stdin;
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.currencies (id, code, name, "isBase", version) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.departments (id, "branchId", name, version) FROM stdin;
\.


--
-- Data for Name: document_counters; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.document_counters (doc_type, last_seq, branch_code, year) FROM stdin;
\.


--
-- Data for Name: document_sequences; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.document_sequences (id, branch_id, document_type, year, current_sequence, prefix, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fx_rates; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.fx_rates (id, "fromCurrencyId", "toCurrencyId", rate, "effectiveFrom", version) FROM stdin;
\.


--
-- Data for Name: goods_received_notes; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.goods_received_notes (id, "grnNumber", "poId", "warehouseId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: grn_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.grn_lines (id, "grnId", "itemId", "quantityReceived", "unitPrice", "lotId") FROM stdin;
\.


--
-- Data for Name: idempotency_logs; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.idempotency_logs (key, "responseBody", "statusCode", "createdAt") FROM stdin;
\.


--
-- Data for Name: inventory_issue_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.inventory_issue_lines (id, "issueId", "itemId", quantity) FROM stdin;
\.


--
-- Data for Name: inventory_issues; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.inventory_issues (id, "issueNumber", "warehouseId", "departmentId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.items (id, "categoryId", "uomId", name, sku, "isBatched", "hasExpiry", version, "createdAt", "isActive", "reorderPoint") FROM stdin;
\.


--
-- Data for Name: kitchen_request_items; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.kitchen_request_items (id, "requestId", "itemId", "quantityRequested", "quantityFulfilled") FROM stdin;
\.


--
-- Data for Name: kitchen_requests; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.kitchen_requests (id, "requestNumber", "departmentId", "warehouseId", status, version, "createdAt", issue_id) FROM stdin;
\.


--
-- Data for Name: landed_cost_allocation_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.landed_cost_allocation_lines (id, "landedCostVoucherId", "grnLineId", "allocatedCost", "adjustedUnitCost", version) FROM stdin;
\.


--
-- Data for Name: landed_cost_grn_relations; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.landed_cost_grn_relations (id, "landedCostVoucherId", "grnId") FROM stdin;
\.


--
-- Data for Name: landed_cost_vouchers; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.landed_cost_vouchers (id, "voucherNumber", "allocationMethod", "totalAllocatedCost", status, "currencyId", "exchangeRate", "transactionDate", "createdAt", "updatedAt", version, "createdById") FROM stdin;
\.


--
-- Data for Name: lot_allocations; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.lot_allocations (id, "issueLineId", "transferLineId", "lotId", "quantityAllocated") FROM stdin;
\.


--
-- Data for Name: lots; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.lots (id, "itemId", "lotNumber", "receivedDate", "expiryDate", status, "createdAt") FROM stdin;
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.notification_logs (id, "targetRole", "warehouseId", message, "isRead", "createdAt", "documentType", "documentId") FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.outbox_events (id, "eventType", payload, status, attempts, "lastError", "processedAt", "createdAt", "expiresAt", "documentId", event_hash, dead_lettered, retry_history) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: po_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.po_lines (id, "poId", "itemId", quantity, "unitPrice") FROM stdin;
\.


--
-- Data for Name: pr_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.pr_lines (id, "prId", "itemId", quantity) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.purchase_orders (id, "poNumber", "prId", "supplierId", status, "currencyId", version, "createdAt") FROM stdin;
\.


--
-- Data for Name: purchase_requests; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.purchase_requests (id, "requestNumber", "branchId", "warehouseId", status, "createdById", version, "createdAt") FROM stdin;
\.


--
-- Data for Name: reconciliation_runs; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.reconciliation_runs (id, "ranAt", "itemsChecked", "discrepanciesFound", "frozenItems", "durationMs", lot_discrepancies_found, wac_drift_count) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.refresh_tokens (id, "tokenHash", "userId", "sessionId", "parentTokenId", "expiresAt", "isRevoked", "createdAt", version) FROM stdin;
\.


--
-- Data for Name: stock_ledger; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stock_ledger (id, "postedAt", "warehouseId", "itemId", "lotId", quantity, "documentId", "documentType", "idempotencyKey") FROM stdin;
\.


--
-- Data for Name: stock_ledger_archive; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stock_ledger_archive (id, "postedAt", "warehouseId", "itemId", "lotId", quantity, "documentId", "documentType", "idempotencyKey", cost_ledger_entries, integrity_hash) FROM stdin;
\.


--
-- Data for Name: stocktake_counts; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stocktake_counts (id, "sessionId", "itemId", "lotId", "qtyCounted", "countedById", "countedAt") FROM stdin;
\.


--
-- Data for Name: stocktake_sessions; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stocktake_sessions (id, "sessionNumber", "warehouseId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: stocktake_snapshots; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.stocktake_snapshots (id, "sessionId", "itemId", "lotId", "qtySnapshot", "wacSnapshot", "createdAt") FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.suppliers (id, name, code, "contactEmail", version, "contactName", "contactPhone", "isActive") FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.system_settings (key, value, version, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: transfer_lines; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.transfer_lines (id, "transferId", "itemId", "quantityShipped", "quantityReceived", "varianceReason", "unitCost") FROM stdin;
\.


--
-- Data for Name: transfers; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.transfers (id, "transferNumber", "fromWarehouseId", "toWarehouseId", status, version, "createdAt") FROM stdin;
\.


--
-- Data for Name: units_of_measure; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.units_of_measure (id, name, code, version) FROM stdin;
\.


--
-- Data for Name: user_warehouse_scopes; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.user_warehouse_scopes (id, "userId", "warehouseId", version) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.users (id, email, "passwordHash", name, role, "isActive", version, "createdAt", "updatedAt", failed_login_attempts, locked_until) FROM stdin;
\.


--
-- Data for Name: warehouse_item_lots; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.warehouse_item_lots ("warehouseId", "itemId", "lotId", "qtyOnHand", "qtyAllocated", "updatedAt") FROM stdin;
\.


--
-- Data for Name: warehouse_items; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.warehouse_items ("warehouseId", "itemId", "qtyOnHand", "qtyAllocated", wac, "updatedAt", is_frozen) FROM stdin;
\.


--
-- Data for Name: warehouse_locks; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.warehouse_locks (id, "warehouseId", "lockType", "lockedById", "expiresAt", "createdAt", "isActive", status) FROM stdin;
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.warehouses (id, "branchId", name, code, "isLocked", version, "createdAt", "isActive") FROM stdin;
\.


--
-- Data for Name: yield_batches; Type: TABLE DATA; Schema: public; Owner: logirest
--

COPY public.yield_batches (id, recipe_name, category, warehouse_id, input_qty, output_qty, waste_qty, yield_pct, standard_yield, efficiency, created_at) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: adjustment_lines adjustment_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustment_lines
    ADD CONSTRAINT adjustment_lines_pkey PRIMARY KEY (id);


--
-- Name: adjustments adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_pkey PRIMARY KEY (id);


--
-- Name: approval_events approval_events_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.approval_events
    ADD CONSTRAINT approval_events_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_archive audit_logs_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.audit_logs_archive
    ADD CONSTRAINT audit_logs_archive_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: barcode_mappings barcode_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.barcode_mappings
    ADD CONSTRAINT barcode_mappings_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cost_ledger_archive cost_ledger_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.cost_ledger_archive
    ADD CONSTRAINT cost_ledger_archive_pkey PRIMARY KEY (id);


--
-- Name: cost_ledger cost_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.cost_ledger
    ADD CONSTRAINT cost_ledger_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: document_counters document_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.document_counters
    ADD CONSTRAINT document_counters_pkey PRIMARY KEY (doc_type, branch_code, year);


--
-- Name: document_sequences document_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_pkey PRIMARY KEY (id);


--
-- Name: fx_rates fx_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT fx_rates_pkey PRIMARY KEY (id);


--
-- Name: goods_received_notes goods_received_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.goods_received_notes
    ADD CONSTRAINT goods_received_notes_pkey PRIMARY KEY (id);


--
-- Name: grn_lines grn_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.grn_lines
    ADD CONSTRAINT grn_lines_pkey PRIMARY KEY (id);


--
-- Name: idempotency_logs idempotency_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.idempotency_logs
    ADD CONSTRAINT idempotency_logs_pkey PRIMARY KEY (key);


--
-- Name: inventory_issue_lines inventory_issue_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issue_lines
    ADD CONSTRAINT inventory_issue_lines_pkey PRIMARY KEY (id);


--
-- Name: inventory_issues inventory_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issues
    ADD CONSTRAINT inventory_issues_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: kitchen_request_items kitchen_request_items_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_request_items
    ADD CONSTRAINT kitchen_request_items_pkey PRIMARY KEY (id);


--
-- Name: kitchen_requests kitchen_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_requests
    ADD CONSTRAINT kitchen_requests_pkey PRIMARY KEY (id);


--
-- Name: landed_cost_allocation_lines landed_cost_allocation_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.landed_cost_allocation_lines
    ADD CONSTRAINT landed_cost_allocation_lines_pkey PRIMARY KEY (id);


--
-- Name: landed_cost_grn_relations landed_cost_grn_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.landed_cost_grn_relations
    ADD CONSTRAINT landed_cost_grn_relations_pkey PRIMARY KEY (id);


--
-- Name: landed_cost_vouchers landed_cost_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.landed_cost_vouchers
    ADD CONSTRAINT landed_cost_vouchers_pkey PRIMARY KEY (id);


--
-- Name: lot_allocations lot_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lot_allocations
    ADD CONSTRAINT lot_allocations_pkey PRIMARY KEY (id);


--
-- Name: lots lots_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT lots_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: po_lines po_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.po_lines
    ADD CONSTRAINT po_lines_pkey PRIMARY KEY (id);


--
-- Name: pr_lines pr_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.pr_lines
    ADD CONSTRAINT pr_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_requests purchase_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_pkey PRIMARY KEY (id);


--
-- Name: reconciliation_runs reconciliation_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.reconciliation_runs
    ADD CONSTRAINT reconciliation_runs_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger_archive stock_ledger_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger_archive
    ADD CONSTRAINT stock_ledger_archive_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger stock_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_pkey PRIMARY KEY (id);


--
-- Name: stocktake_counts stocktake_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT stocktake_counts_pkey PRIMARY KEY (id);


--
-- Name: stocktake_sessions stocktake_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_sessions
    ADD CONSTRAINT stocktake_sessions_pkey PRIMARY KEY (id);


--
-- Name: stocktake_snapshots stocktake_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_snapshots
    ADD CONSTRAINT stocktake_snapshots_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: transfer_lines transfer_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfer_lines
    ADD CONSTRAINT transfer_lines_pkey PRIMARY KEY (id);


--
-- Name: transfers transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_pkey PRIMARY KEY (id);


--
-- Name: units_of_measure units_of_measure_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_pkey PRIMARY KEY (id);


--
-- Name: user_warehouse_scopes user_warehouse_scopes_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.user_warehouse_scopes
    ADD CONSTRAINT user_warehouse_scopes_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouse_item_lots warehouse_item_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT warehouse_item_lots_pkey PRIMARY KEY ("warehouseId", "itemId", "lotId");


--
-- Name: warehouse_items warehouse_items_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT warehouse_items_pkey PRIMARY KEY ("warehouseId", "itemId");


--
-- Name: warehouse_locks warehouse_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_locks
    ADD CONSTRAINT warehouse_locks_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: yield_batches yield_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.yield_batches
    ADD CONSTRAINT yield_batches_pkey PRIMARY KEY (id);


--
-- Name: adjustments_adjustmentNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "adjustments_adjustmentNumber_key" ON public.adjustments USING btree ("adjustmentNumber");


--
-- Name: approval_events_documentId_documentType_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "approval_events_documentId_documentType_idx" ON public.approval_events USING btree ("documentId", "documentType");


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt" DESC);


--
-- Name: audit_logs_targetTable_targetId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "audit_logs_targetTable_targetId_idx" ON public.audit_logs USING btree ("targetTable", "targetId");


--
-- Name: audit_logs_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "audit_logs_userId_createdAt_idx" ON public.audit_logs USING btree ("userId", "createdAt" DESC);


--
-- Name: barcode_mappings_barcode_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX barcode_mappings_barcode_key ON public.barcode_mappings USING btree (barcode);


--
-- Name: branches_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX branches_code_key ON public.branches USING btree (code);


--
-- Name: branches_name_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX branches_name_key ON public.branches USING btree (name);


--
-- Name: categories_name_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX categories_name_key ON public.categories USING btree (name);


--
-- Name: cost_ledger_documentId_documentType_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "cost_ledger_documentId_documentType_idx" ON public.cost_ledger USING btree ("documentId", "documentType");


--
-- Name: cost_ledger_documentId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "cost_ledger_documentId_idx" ON public.cost_ledger USING btree ("documentId");


--
-- Name: cost_ledger_idempotencyKey_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "cost_ledger_idempotencyKey_key" ON public.cost_ledger USING btree ("idempotencyKey");


--
-- Name: cost_ledger_warehouseId_itemId_postedAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "cost_ledger_warehouseId_itemId_postedAt_idx" ON public.cost_ledger USING btree ("warehouseId", "itemId", "postedAt" DESC);


--
-- Name: currencies_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX currencies_code_key ON public.currencies USING btree (code);


--
-- Name: document_counters_doc_type_branch_code_year_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX document_counters_doc_type_branch_code_year_idx ON public.document_counters USING btree (doc_type, branch_code, year);


--
-- Name: document_sequences_document_type_year_branch_id_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX document_sequences_document_type_year_branch_id_key ON public.document_sequences USING btree (document_type, year, branch_id);


--
-- Name: fx_rates_fromCurrencyId_toCurrencyId_effectiveFrom_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "fx_rates_fromCurrencyId_toCurrencyId_effectiveFrom_key" ON public.fx_rates USING btree ("fromCurrencyId", "toCurrencyId", "effectiveFrom");


--
-- Name: goods_received_notes_grnNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "goods_received_notes_grnNumber_key" ON public.goods_received_notes USING btree ("grnNumber");


--
-- Name: goods_received_notes_status_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX goods_received_notes_status_idx ON public.goods_received_notes USING btree (status);


--
-- Name: grns_grnNumber_trgm_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "grns_grnNumber_trgm_idx" ON public.goods_received_notes USING gin ("grnNumber" public.gin_trgm_ops);


--
-- Name: inventory_issues_issueNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "inventory_issues_issueNumber_key" ON public.inventory_issues USING btree ("issueNumber");


--
-- Name: issues_issueNumber_trgm_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "issues_issueNumber_trgm_idx" ON public.inventory_issues USING gin ("issueNumber" public.gin_trgm_ops);


--
-- Name: items_name_trgm_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX items_name_trgm_idx ON public.items USING gin (name public.gin_trgm_ops);


--
-- Name: items_sku_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX items_sku_key ON public.items USING btree (sku);


--
-- Name: items_sku_trgm_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX items_sku_trgm_idx ON public.items USING gin (sku public.gin_trgm_ops);


--
-- Name: kitchen_requests_issue_id_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX kitchen_requests_issue_id_key ON public.kitchen_requests USING btree (issue_id);


--
-- Name: kitchen_requests_requestNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "kitchen_requests_requestNumber_key" ON public.kitchen_requests USING btree ("requestNumber");


--
-- Name: landed_cost_grn_relations_landedCostVoucherId_grnId_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "landed_cost_grn_relations_landedCostVoucherId_grnId_key" ON public.landed_cost_grn_relations USING btree ("landedCostVoucherId", "grnId");


--
-- Name: landed_cost_vouchers_voucherNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "landed_cost_vouchers_voucherNumber_key" ON public.landed_cost_vouchers USING btree ("voucherNumber");


--
-- Name: lot_allocations_issueLineId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "lot_allocations_issueLineId_idx" ON public.lot_allocations USING btree ("issueLineId");


--
-- Name: lot_allocations_transferLineId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "lot_allocations_transferLineId_idx" ON public.lot_allocations USING btree ("transferLineId");


--
-- Name: lots_itemId_expiryDate_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "lots_itemId_expiryDate_idx" ON public.lots USING btree ("itemId", "expiryDate");


--
-- Name: lots_lotNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "lots_lotNumber_key" ON public.lots USING btree ("lotNumber");


--
-- Name: lots_lotNumber_trgm_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "lots_lotNumber_trgm_idx" ON public.lots USING gin ("lotNumber" public.gin_trgm_ops);


--
-- Name: notification_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "notification_logs_createdAt_idx" ON public.notification_logs USING btree ("createdAt" DESC);


--
-- Name: notification_logs_targetRole_isRead_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "notification_logs_targetRole_isRead_idx" ON public.notification_logs USING btree ("targetRole", "isRead");


--
-- Name: notification_logs_warehouseId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "notification_logs_warehouseId_idx" ON public.notification_logs USING btree ("warehouseId");


--
-- Name: outbox_event_hash_unique; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX outbox_event_hash_unique ON public.outbox_events USING btree (event_hash) WHERE (event_hash IS NOT NULL);


--
-- Name: outbox_events_status_createdAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "outbox_events_status_createdAt_idx" ON public.outbox_events USING btree (status, "createdAt");


--
-- Name: password_reset_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX password_reset_tokens_expires_at_idx ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: password_reset_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX password_reset_tokens_token_hash_key ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: password_reset_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX password_reset_tokens_user_id_idx ON public.password_reset_tokens USING btree (user_id);


--
-- Name: pos_poNumber_trgm_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "pos_poNumber_trgm_idx" ON public.purchase_orders USING gin ("poNumber" public.gin_trgm_ops);


--
-- Name: purchase_orders_poNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "purchase_orders_poNumber_key" ON public.purchase_orders USING btree ("poNumber");


--
-- Name: purchase_orders_prId_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "purchase_orders_prId_key" ON public.purchase_orders USING btree ("prId");


--
-- Name: purchase_requests_requestNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "purchase_requests_requestNumber_key" ON public.purchase_requests USING btree ("requestNumber");


--
-- Name: refresh_tokens_expiresAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "refresh_tokens_expiresAt_idx" ON public.refresh_tokens USING btree ("expiresAt");


--
-- Name: refresh_tokens_sessionId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "refresh_tokens_sessionId_idx" ON public.refresh_tokens USING btree ("sessionId");


--
-- Name: refresh_tokens_tokenHash_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "refresh_tokens_tokenHash_key" ON public.refresh_tokens USING btree ("tokenHash");


--
-- Name: refresh_tokens_userId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "refresh_tokens_userId_idx" ON public.refresh_tokens USING btree ("userId");


--
-- Name: stock_ledger_documentId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "stock_ledger_documentId_idx" ON public.stock_ledger USING btree ("documentId");


--
-- Name: stock_ledger_idempotencyKey_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "stock_ledger_idempotencyKey_key" ON public.stock_ledger USING btree ("idempotencyKey");


--
-- Name: stock_ledger_warehouseId_itemId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "stock_ledger_warehouseId_itemId_idx" ON public.stock_ledger USING btree ("warehouseId", "itemId");


--
-- Name: stock_ledger_warehouseId_itemId_postedAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "stock_ledger_warehouseId_itemId_postedAt_idx" ON public.stock_ledger USING btree ("warehouseId", "itemId", "postedAt" DESC);


--
-- Name: stocktake_sessions_sessionNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "stocktake_sessions_sessionNumber_key" ON public.stocktake_sessions USING btree ("sessionNumber");


--
-- Name: suppliers_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX suppliers_code_key ON public.suppliers USING btree (code);


--
-- Name: suppliers_code_trgm_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX suppliers_code_trgm_idx ON public.suppliers USING gin (code public.gin_trgm_ops);


--
-- Name: suppliers_name_trgm_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX suppliers_name_trgm_idx ON public.suppliers USING gin (name public.gin_trgm_ops);


--
-- Name: transfers_transferNumber_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "transfers_transferNumber_key" ON public.transfers USING btree ("transferNumber");


--
-- Name: transfers_transferNumber_trgm_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "transfers_transferNumber_trgm_idx" ON public.transfers USING gin ("transferNumber" public.gin_trgm_ops);


--
-- Name: units_of_measure_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX units_of_measure_code_key ON public.units_of_measure USING btree (code);


--
-- Name: units_of_measure_name_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX units_of_measure_name_key ON public.units_of_measure USING btree (name);


--
-- Name: user_warehouse_scopes_userId_warehouseId_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX "user_warehouse_scopes_userId_warehouseId_key" ON public.user_warehouse_scopes USING btree ("userId", "warehouseId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: warehouse_item_lots_warehouseId_itemId_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "warehouse_item_lots_warehouseId_itemId_idx" ON public.warehouse_item_lots USING btree ("warehouseId", "itemId");


--
-- Name: warehouse_locks_isActive_expiresAt_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "warehouse_locks_isActive_expiresAt_idx" ON public.warehouse_locks USING btree ("isActive", "expiresAt");


--
-- Name: warehouse_locks_warehouseId_isActive_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX "warehouse_locks_warehouseId_isActive_idx" ON public.warehouse_locks USING btree ("warehouseId", "isActive");


--
-- Name: warehouses_code_key; Type: INDEX; Schema: public; Owner: logirest
--

CREATE UNIQUE INDEX warehouses_code_key ON public.warehouses USING btree (code);


--
-- Name: yield_batches_warehouse_id_idx; Type: INDEX; Schema: public; Owner: logirest
--

CREATE INDEX yield_batches_warehouse_id_idx ON public.yield_batches USING btree (warehouse_id);


--
-- Name: cost_ledger cost_ledger_immutable; Type: TRIGGER; Schema: public; Owner: logirest
--

CREATE TRIGGER cost_ledger_immutable BEFORE DELETE OR UPDATE ON public.cost_ledger FOR EACH ROW EXECUTE FUNCTION public.prevent_ledger_mutation();


--
-- Name: stock_ledger stock_ledger_immutable; Type: TRIGGER; Schema: public; Owner: logirest
--

CREATE TRIGGER stock_ledger_immutable BEFORE DELETE OR UPDATE ON public.stock_ledger FOR EACH ROW EXECUTE FUNCTION public.prevent_ledger_mutation();


--
-- Name: adjustment_lines adjustment_lines_adjustmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustment_lines
    ADD CONSTRAINT "adjustment_lines_adjustmentId_fkey" FOREIGN KEY ("adjustmentId") REFERENCES public.adjustments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: adjustment_lines adjustment_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustment_lines
    ADD CONSTRAINT "adjustment_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: adjustment_lines adjustment_lines_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustment_lines
    ADD CONSTRAINT "adjustment_lines_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: adjustments adjustments_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT "adjustments_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_events approval_events_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.approval_events
    ADD CONSTRAINT "approval_events_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: barcode_mappings barcode_mappings_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.barcode_mappings
    ADD CONSTRAINT "barcode_mappings_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cost_ledger cost_ledger_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.cost_ledger
    ADD CONSTRAINT "cost_ledger_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cost_ledger cost_ledger_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.cost_ledger
    ADD CONSTRAINT "cost_ledger_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: departments departments_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT "departments_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public.branches(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_sequences document_sequences_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fx_rates fx_rates_fromCurrencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT "fx_rates_fromCurrencyId_fkey" FOREIGN KEY ("fromCurrencyId") REFERENCES public.currencies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fx_rates fx_rates_toCurrencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT "fx_rates_toCurrencyId_fkey" FOREIGN KEY ("toCurrencyId") REFERENCES public.currencies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_received_notes goods_received_notes_poId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.goods_received_notes
    ADD CONSTRAINT "goods_received_notes_poId_fkey" FOREIGN KEY ("poId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_received_notes goods_received_notes_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.goods_received_notes
    ADD CONSTRAINT "goods_received_notes_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: grn_lines grn_lines_grnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.grn_lines
    ADD CONSTRAINT "grn_lines_grnId_fkey" FOREIGN KEY ("grnId") REFERENCES public.goods_received_notes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grn_lines grn_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.grn_lines
    ADD CONSTRAINT "grn_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: grn_lines grn_lines_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.grn_lines
    ADD CONSTRAINT "grn_lines_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: inventory_issue_lines inventory_issue_lines_issueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issue_lines
    ADD CONSTRAINT "inventory_issue_lines_issueId_fkey" FOREIGN KEY ("issueId") REFERENCES public.inventory_issues(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_issue_lines inventory_issue_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issue_lines
    ADD CONSTRAINT "inventory_issue_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inventory_issues inventory_issues_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issues
    ADD CONSTRAINT "inventory_issues_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inventory_issues inventory_issues_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.inventory_issues
    ADD CONSTRAINT "inventory_issues_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: items items_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT "items_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: items items_uomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT "items_uomId_fkey" FOREIGN KEY ("uomId") REFERENCES public.units_of_measure(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kitchen_request_items kitchen_request_items_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_request_items
    ADD CONSTRAINT "kitchen_request_items_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kitchen_request_items kitchen_request_items_requestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_request_items
    ADD CONSTRAINT "kitchen_request_items_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES public.kitchen_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kitchen_requests kitchen_requests_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_requests
    ADD CONSTRAINT "kitchen_requests_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kitchen_requests kitchen_requests_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_requests
    ADD CONSTRAINT kitchen_requests_issue_id_fkey FOREIGN KEY (issue_id) REFERENCES public.inventory_issues(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: kitchen_requests kitchen_requests_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.kitchen_requests
    ADD CONSTRAINT "kitchen_requests_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: landed_cost_allocation_lines landed_cost_allocation_lines_grnLineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.landed_cost_allocation_lines
    ADD CONSTRAINT "landed_cost_allocation_lines_grnLineId_fkey" FOREIGN KEY ("grnLineId") REFERENCES public.grn_lines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: landed_cost_allocation_lines landed_cost_allocation_lines_landedCostVoucherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.landed_cost_allocation_lines
    ADD CONSTRAINT "landed_cost_allocation_lines_landedCostVoucherId_fkey" FOREIGN KEY ("landedCostVoucherId") REFERENCES public.landed_cost_vouchers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: landed_cost_grn_relations landed_cost_grn_relations_grnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.landed_cost_grn_relations
    ADD CONSTRAINT "landed_cost_grn_relations_grnId_fkey" FOREIGN KEY ("grnId") REFERENCES public.goods_received_notes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: landed_cost_grn_relations landed_cost_grn_relations_landedCostVoucherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.landed_cost_grn_relations
    ADD CONSTRAINT "landed_cost_grn_relations_landedCostVoucherId_fkey" FOREIGN KEY ("landedCostVoucherId") REFERENCES public.landed_cost_vouchers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: landed_cost_vouchers landed_cost_vouchers_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.landed_cost_vouchers
    ADD CONSTRAINT "landed_cost_vouchers_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lot_allocations lot_allocations_issueLineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lot_allocations
    ADD CONSTRAINT "lot_allocations_issueLineId_fkey" FOREIGN KEY ("issueLineId") REFERENCES public.inventory_issue_lines(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lot_allocations lot_allocations_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lot_allocations
    ADD CONSTRAINT "lot_allocations_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lot_allocations lot_allocations_transferLineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lot_allocations
    ADD CONSTRAINT "lot_allocations_transferLineId_fkey" FOREIGN KEY ("transferLineId") REFERENCES public.transfer_lines(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lots lots_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT "lots_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: po_lines po_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.po_lines
    ADD CONSTRAINT "po_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: po_lines po_lines_poId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.po_lines
    ADD CONSTRAINT "po_lines_poId_fkey" FOREIGN KEY ("poId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pr_lines pr_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.pr_lines
    ADD CONSTRAINT "pr_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pr_lines pr_lines_prId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.pr_lines
    ADD CONSTRAINT "pr_lines_prId_fkey" FOREIGN KEY ("prId") REFERENCES public.purchase_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_currencyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_currencyId_fkey" FOREIGN KEY ("currencyId") REFERENCES public.currencies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_orders purchase_orders_prId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_prId_fkey" FOREIGN KEY ("prId") REFERENCES public.purchase_requests(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_requests purchase_requests_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT "purchase_requests_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public.branches(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_requests purchase_requests_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT "purchase_requests_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_requests purchase_requests_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT "purchase_requests_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refresh_tokens refresh_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_ledger stock_ledger_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT "stock_ledger_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_ledger stock_ledger_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT "stock_ledger_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_ledger stock_ledger_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT "stock_ledger_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_counts stocktake_counts_countedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT "stocktake_counts_countedById_fkey" FOREIGN KEY ("countedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_counts stocktake_counts_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT "stocktake_counts_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_counts stocktake_counts_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT "stocktake_counts_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_counts stocktake_counts_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_counts
    ADD CONSTRAINT "stocktake_counts_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.stocktake_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stocktake_sessions stocktake_sessions_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_sessions
    ADD CONSTRAINT "stocktake_sessions_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_snapshots stocktake_snapshots_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_snapshots
    ADD CONSTRAINT "stocktake_snapshots_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_snapshots stocktake_snapshots_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_snapshots
    ADD CONSTRAINT "stocktake_snapshots_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stocktake_snapshots stocktake_snapshots_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.stocktake_snapshots
    ADD CONSTRAINT "stocktake_snapshots_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.stocktake_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transfer_lines transfer_lines_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfer_lines
    ADD CONSTRAINT "transfer_lines_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transfer_lines transfer_lines_transferId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfer_lines
    ADD CONSTRAINT "transfer_lines_transferId_fkey" FOREIGN KEY ("transferId") REFERENCES public.transfers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transfers transfers_fromWarehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT "transfers_fromWarehouseId_fkey" FOREIGN KEY ("fromWarehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transfers transfers_toWarehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT "transfers_toWarehouseId_fkey" FOREIGN KEY ("toWarehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_warehouse_scopes user_warehouse_scopes_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.user_warehouse_scopes
    ADD CONSTRAINT "user_warehouse_scopes_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_warehouse_scopes user_warehouse_scopes_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.user_warehouse_scopes
    ADD CONSTRAINT "user_warehouse_scopes_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: warehouse_item_lots warehouse_item_lots_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT "warehouse_item_lots_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_item_lots warehouse_item_lots_lotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT "warehouse_item_lots_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_item_lots warehouse_item_lots_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT "warehouse_item_lots_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_item_lots warehouse_item_lots_warehouseId_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_item_lots
    ADD CONSTRAINT "warehouse_item_lots_warehouseId_itemId_fkey" FOREIGN KEY ("warehouseId", "itemId") REFERENCES public.warehouse_items("warehouseId", "itemId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: warehouse_items warehouse_items_itemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT "warehouse_items_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES public.items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_items warehouse_items_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_items
    ADD CONSTRAINT "warehouse_items_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_locks warehouse_locks_lockedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_locks
    ADD CONSTRAINT "warehouse_locks_lockedById_fkey" FOREIGN KEY ("lockedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouse_locks warehouse_locks_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouse_locks
    ADD CONSTRAINT "warehouse_locks_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: warehouses warehouses_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT "warehouses_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public.branches(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: yield_batches yield_batches_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: logirest
--

ALTER TABLE ONLY public.yield_batches
    ADD CONSTRAINT yield_batches_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 8KichCrEKiVLsFRGx7DgGI5ntjpzv4Eww0HKIcvih0L7IRMkdov7G44IKl5DzJ1

